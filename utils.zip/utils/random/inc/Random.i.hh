#include "Random.hh"

#include <systemc>
#include <stdint.h>

namespace utils {

namespace random {


template<size_t bits>
sc_dt::sc_lv< bits > getRandomBits(void)
{
  sc_dt::sc_lv< bits > ret;
  for (size_t i = 0; i < bits; ++i) ret[i] = getRandomLogic();

  return ret;
}

} // Namespace

} // Namespace
