#ifndef UTILS_RANDOM_HH
#define UTILS_RANDOM_HH

#include <systemc>
#include <stdint.h>

namespace utils {

namespace random {

bool getRandomBoolean(void);
sc_dt::sc_logic getRandomLogic(void);

template<size_t bits>
sc_dt::sc_lv< bits > getRandomBits(void);

uint32_t getRandom32Bits(void);

} // Namespace

} // Namespace

#include "Random.i.hh"
#endif
