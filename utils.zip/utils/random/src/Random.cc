#include "Random.hh"

#include <cstdlib>

namespace utils {

namespace random {

// Note: generate boolean value

bool getRandomBoolean(void) 
{  
  return (rand() % 2 == 0);
}
   
// Note: generate logic value
 
sc_dt::sc_logic getRandomLogic(void) 
{  
  return sc_dt::sc_logic(getRandomBoolean());
}

// Note: generate integer value

uint32_t getRandom32Bits(void) 
{   
  // Note: RAND_MAX is guaranteed to be at least 32767,
  // therefore multiple calls are necessary in this case 
   
  uint32_t value = rand() & 0xff;
  value |= ((rand() & 0xff) << 8);
  value |= ((rand() & 0xff) << 16);
  value |= ((rand() & 0xff) << 24);
  return value;
  
}
  
} // Namespace

} // Namespace
