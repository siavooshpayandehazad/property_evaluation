# Copyright (C) 2017 Siavoosh Payandeh Azad
# License: GNU GENERAL PUBLIC LICENSE Version 3


DUT_path = "DUTs/arbiter/"
results_path = "results"
tb_path = "results/TB"
do_path = "results/do_files"
cov_path = "results/cov_files"
cov_detailed_path = "results/cov_files/detailed"
reports_path = "results/reports"

sys_arguments = {"input_property_file" : None,
				 "testbench_file" : None
				}