To evaluate code coverage of each assertions:
run in Terminal:
 python main.py -i arbiter_assertion_1.rtf


note: main.py tale a rtf file.

