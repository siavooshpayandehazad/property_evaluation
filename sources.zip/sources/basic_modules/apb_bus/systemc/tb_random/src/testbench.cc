#include "../inc/testbench.hh"

// CONSTRUCTOR

testbench::testbench(sc_core::sc_module_name name)
  : _seed(1000), _sequences(10), _length(10000)
{
  SC_THREAD(clk_gen);
  SC_THREAD(run);
  sensitive << clk;
}

// Destructor

testbench::~testbench()
{
  // Nothing to do
}

// Public methods

void testbench::set_length(unsigned int seed, 
                           unsigned int sequences, unsigned int length)
{
  _seed = seed;
  _sequences = sequences;
  _length = length;
}

// Private methods

void testbench::clk_gen() 
{
  while (true) 
  {
    clk.write(sc_dt::sc_logic('1'));
    wait(PERIOD / 2, sc_core::SC_NS);
    clk.write(sc_dt::sc_logic('0'));
    wait(PERIOD / 2, sc_core::SC_NS);
  }
}

void testbench::run()
{
  srand(_seed);

  for (int i = 0; i < _sequences; ++i)
  {
    // reset for devices
    apb_master_presetn.write(sc_dt::sc_logic('1'));
    wait();
    apb_master_presetn.write(sc_dt::sc_logic('0'));
      
      
    for (int j = 0; j < _length; ++j)
    {
        // enable for devices (random)
        apb_master_penable.write(utils::random::getRandomLogic());
        
        // psel
        apb_master_psel0.write(utils::random::getRandomLogic());
        apb_master_psel1.write(utils::random::getRandomLogic());
        apb_master_psel2.write(utils::random::getRandomLogic());
        
        // address
        apb_master_paddr.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
        
        // read or write ?
        if (utils::random::getRandomBoolean()) // write
        {
            apb_master_pwdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
            apb_master_pwrite.write(sc_dt::sc_logic('1'));
            wait();
        }
        else // read
        {
            // random data for devices
            apb_1_prdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
            apb_2_prdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
            apb_3_prdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
            
            apb_master_pwrite.write(sc_dt::sc_logic('0'));
            wait();
        }
        wait();
    }
  }

  sc_core::sc_stop();
}
