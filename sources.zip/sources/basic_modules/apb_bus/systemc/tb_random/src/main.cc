#include "../inc/testbench.hh"
#include "../../module/inc/apb_bus.hh"
#include <iostream>

int sc_main(int argc, char **argv)
{
  if (argc == 4)
  {
    // 1. Create testbench
    testbench testbench("testbench");
    testbench.set_length(atoi(argv[1]), atoi(argv[2]) , atoi(argv[3]));
    
    // 2. Create design under test (dut)
    apb_bus design("design_under_test");
    
    // 3. Connect testbench and dut
    sc_core::sc_signal< sc_dt::sc_logic > clk;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_master_prdata;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_master_pwdata;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_psel0;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_psel1;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_psel2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_penable;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_pwrite;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_master_paddr;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_presetn;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_clk;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_presetn;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_clk;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_psel;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_penable;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_pwrite;
    sc_core::sc_signal< sc_dt::sc_lv< 3L > > apb_1_paddr;
    sc_core::sc_signal< sc_dt::sc_lv< 8L > > apb_1_prdata;
    sc_core::sc_signal< sc_dt::sc_lv< 8L > > apb_1_pwdata;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_presetn;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_clk;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_psel;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_penable;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_pwrite;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_2_paddr;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_2_prdata;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_2_pwdata;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_presetn;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_clk;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_psel;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_penable;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_pwrite;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_3_paddr;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_3_prdata;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_3_pwdata;
   
    design.clk(clk);                                testbench.clk(clk);
    design.apb_master_prdata(apb_master_prdata);    testbench.apb_master_prdata(apb_master_prdata);
    design.apb_master_pwdata(apb_master_pwdata);    testbench.apb_master_pwdata(apb_master_pwdata);
    design.apb_master_psel0(apb_master_psel0);      testbench.apb_master_psel0(apb_master_psel0);
    design.apb_master_psel1(apb_master_psel1);      testbench.apb_master_psel1(apb_master_psel1);
    design.apb_master_psel2(apb_master_psel2);      testbench.apb_master_psel2(apb_master_psel2);
    design.apb_master_penable(apb_master_penable);  testbench.apb_master_penable(apb_master_penable);
    design.apb_master_pwrite(apb_master_pwrite);    testbench.apb_master_pwrite(apb_master_pwrite);
    design.apb_master_paddr(apb_master_paddr);      testbench.apb_master_paddr(apb_master_paddr);
    design.apb_master_presetn(apb_master_presetn);  testbench.apb_master_presetn(apb_master_presetn);
    design.apb_master_clk(apb_master_clk);          testbench.apb_master_clk(apb_master_clk);      
    design.apb_1_presetn(apb_1_presetn);            testbench.apb_1_presetn(apb_1_presetn);
    design.apb_1_clk(apb_1_clk);                    testbench.apb_1_clk(apb_1_clk);
    design.apb_1_psel(apb_1_psel);                  testbench.apb_1_psel(apb_1_psel);
    design.apb_1_penable(apb_1_penable);            testbench.apb_1_penable(apb_1_penable);
    design.apb_1_pwrite(apb_1_pwrite);              testbench.apb_1_pwrite(apb_1_pwrite);
    design.apb_1_paddr(apb_1_paddr);                testbench.apb_1_paddr(apb_1_paddr);
    design.apb_1_prdata(apb_1_prdata);              testbench.apb_1_prdata(apb_1_prdata);
    design.apb_1_pwdata(apb_1_pwdata);              testbench.apb_1_pwdata(apb_1_pwdata);      
    design.apb_2_presetn(apb_2_presetn);            testbench.apb_2_presetn(apb_2_presetn);
    design.apb_2_clk(apb_2_clk);                    testbench.apb_2_clk(apb_2_clk);
    design.apb_2_psel(apb_2_psel);                  testbench.apb_2_psel(apb_2_psel);
    design.apb_2_penable(apb_2_penable);            testbench.apb_2_penable(apb_2_penable);
    design.apb_2_pwrite(apb_2_pwrite);              testbench.apb_2_pwrite(apb_2_pwrite);
    design.apb_2_paddr(apb_2_paddr);                testbench.apb_2_paddr(apb_2_paddr);
    design.apb_2_prdata(apb_2_prdata);              testbench.apb_2_prdata(apb_2_prdata);
    design.apb_2_pwdata(apb_2_pwdata);              testbench.apb_2_pwdata(apb_2_pwdata);     
    design.apb_3_presetn(apb_3_presetn);            testbench.apb_3_presetn(apb_3_presetn);
    design.apb_3_clk(apb_3_clk);                    testbench.apb_3_clk(apb_3_clk);
    design.apb_3_psel(apb_3_psel);                  testbench.apb_3_psel(apb_3_psel);
    design.apb_3_penable(apb_3_penable);            testbench.apb_3_penable(apb_3_penable);
    design.apb_3_pwrite(apb_3_pwrite);              testbench.apb_3_pwrite(apb_3_pwrite);
    design.apb_3_paddr(apb_3_paddr);                testbench.apb_3_paddr(apb_3_paddr);
    design.apb_3_prdata(apb_3_prdata);              testbench.apb_3_prdata(apb_3_prdata);
    design.apb_3_pwdata(apb_3_pwdata);              testbench.apb_3_pwdata(apb_3_pwdata);
      
    // 4. Trace the signals of interest
    sc_core::sc_trace_file * tf_numeric = sc_core::sc_create_vcd_trace_file("apb_numeric");
    sc_core::sc_trace_file * tf_boolean = sc_core::sc_create_vcd_trace_file("apb_boolean");
    tf_numeric->set_time_unit(PERIOD / 2, sc_core::SC_NS); 
    tf_boolean->set_time_unit(PERIOD / 2, sc_core::SC_NS);

    // 4.1. Trace numeric signals    
    sc_core::sc_trace(tf_numeric, design.apb_master_prdata, "apb_master_prdata");
    sc_core::sc_trace(tf_numeric, design.apb_master_pwdata, "apb_master_pwdata");
    sc_core::sc_trace(tf_numeric, design.apb_master_paddr, "apb_master_paddr");
    sc_core::sc_trace(tf_numeric, design.apb_1_paddr, "apb_1_paddr");
    sc_core::sc_trace(tf_numeric, design.apb_2_paddr, "apb_2_paddr");
    sc_core::sc_trace(tf_numeric, design.apb_3_paddr, "apb_3_paddr");
    sc_core::sc_trace(tf_numeric, design.apb_1_prdata, "apb_1_prdata");
    sc_core::sc_trace(tf_numeric, design.apb_2_prdata, "apb_2_prdata");
    sc_core::sc_trace(tf_numeric, design.apb_3_prdata, "apb_3_prdata");
    sc_core::sc_trace(tf_numeric, design.apb_1_pwdata, "apb_1_pwdata");
    sc_core::sc_trace(tf_numeric, design.apb_2_pwdata, "apb_2_pwdata");
    sc_core::sc_trace(tf_numeric, design.apb_3_pwdata, "apb_3_pwdata");
    sc_core::sc_trace(tf_numeric, design.addr, "addr");
    sc_core::sc_trace(tf_numeric, design.wdata, "wdata");
    sc_core::sc_trace(tf_numeric, design.rdata, "rdata");
    sc_core::sc_trace(tf_numeric, design.rdata_var, "rdata_var");
         
    // 4.2. Trace boolean signals  
    // sc_core::sc_trace(tf, design.clk, "clk");
    // sc_core::sc_trace(tf_boolean, design.apb_master_clk, "apb_master_clk");
    // sc_core::sc_trace(tf_boolean, design.apb_1_clk, "apb_1_clk");
    // sc_core::sc_trace(tf_boolean, design.apb_2_clk, "apb_2_clk");
    // sc_core::sc_trace(tf_boolean, design.apb_3_clk, "apb_3_clk");
    sc_core::sc_trace(tf_boolean, design.apb_master_psel0, "apb_master_psel0");
    sc_core::sc_trace(tf_boolean, design.apb_master_psel1, "apb_master_psel1");
    sc_core::sc_trace(tf_boolean, design.apb_master_psel2, "apb_master_psel2");
    sc_core::sc_trace(tf_boolean, design.apb_1_psel, "apb_1_psel");
    sc_core::sc_trace(tf_boolean, design.apb_2_psel, "apb_2_psel");
    sc_core::sc_trace(tf_boolean, design.apb_3_psel, "apb_3_psel");      
    sc_core::sc_trace(tf_boolean, design.apb_master_presetn, "apb_master_presetn");
    sc_core::sc_trace(tf_boolean, design.apb_1_presetn, "apb_1_presetn");
    sc_core::sc_trace(tf_boolean, design.apb_2_presetn, "apb_2_presetn");
    sc_core::sc_trace(tf_boolean, design.apb_3_presetn, "apb_3_presetn");      
    sc_core::sc_trace(tf_boolean, design.apb_master_penable, "apb_master_penable");
    sc_core::sc_trace(tf_boolean, design.apb_1_penable, "apb_1_penable");
    sc_core::sc_trace(tf_boolean, design.apb_2_penable, "apb_2_penable");
    sc_core::sc_trace(tf_boolean, design.apb_3_penable, "apb_3_penable");      
    sc_core::sc_trace(tf_boolean, design.apb_master_pwrite, "apb_master_pwrite");
    sc_core::sc_trace(tf_boolean, design.apb_1_pwrite, "apb_1_pwrite");
    sc_core::sc_trace(tf_boolean, design.apb_2_pwrite, "apb_2_pwrite");
    sc_core::sc_trace(tf_boolean, design.apb_3_pwrite, "apb_3_pwrite");
    sc_core::sc_trace(tf_boolean, design.sel0, "sel0");
    sc_core::sc_trace(tf_boolean, design.sel1, "sel1");
    sc_core::sc_trace(tf_boolean, design.sel2, "sel2");
    sc_core::sc_trace(tf_boolean, design.enable, "enable");
    sc_core::sc_trace(tf_boolean, design.write, "write");
    sc_core::sc_trace(tf_boolean, design.resetn, "resetn");
      
    sc_core::sc_start(); 
    
    sc_core::sc_close_vcd_trace_file(tf_numeric);
    sc_core::sc_close_vcd_trace_file(tf_boolean);
    
    return 0;
  }
  else
  {
    std::cout << "\nUse in one of the following ways:\n\n"
      << "   ./root_tb_random [seed] [sequence_number] [sequence_length]\n\n";
    return 1;
  }
}
