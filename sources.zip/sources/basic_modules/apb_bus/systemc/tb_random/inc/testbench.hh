#ifndef TESTBENCH_RANDOM__HH
#define TESTBENCH_RANDOM__HH

#include "../../../../../../utils/random/inc/Random.hh"

#define PERIOD 500
#include <systemc>

class testbench :
    public sc_core::sc_module
{

public:

    sc_core::sc_out< sc_dt::sc_logic > clk;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_master_prdata;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_master_pwdata;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_psel0;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_psel1;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_psel2;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_penable;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_pwrite;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_master_paddr;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_presetn;
    sc_core::sc_in< sc_dt::sc_logic > apb_master_clk;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_presetn;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_clk;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_psel;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_penable;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_pwrite;
    sc_core::sc_in< sc_dt::sc_lv< 3L > > apb_1_paddr;
    sc_core::sc_out< sc_dt::sc_lv< 8L > > apb_1_prdata;
    sc_core::sc_in< sc_dt::sc_lv< 8L > > apb_1_pwdata;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_presetn;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_clk;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_psel;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_penable;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_pwrite;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_2_paddr;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_2_prdata;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_2_pwdata;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_presetn;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_clk;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_psel;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_penable;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_pwrite;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_3_paddr;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_3_prdata;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_3_pwdata;
      
    SC_HAS_PROCESS(testbench);
    testbench(sc_core::sc_module_name name_);
    ~testbench();
    
    void set_length(unsigned int seed, unsigned 
                    int sequences, unsigned int length);
      
  private:

    unsigned int _seed;
    unsigned int _sequences;
    unsigned int _length;

    void clk_gen();
    void run();
};

#endif

