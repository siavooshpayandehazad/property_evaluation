/* Matteo Calabria */

#ifndef STUCK_AT_MUT_LIBRARY_HH
#define STUCK_AT_MUT_LIBRARY_HH

#include <systemc>

namespace splinter{

namespace mutationLibraries {

  // sc_lv, sc_bv, int, double, ..., uint8_t, ... , uint64_t
  //template<typename T, unsigned int W = 1>
  //template<class T>
  //template<typename T>
  //T stuckAt(T& right, uint32_t min, uint32_t max, uint32_t current, bool isActive);
  template<typename T>
  T stuckAt(T right, uint32_t min, uint32_t max, uint32_t current, bool isActive);

  template<typename T>
  T stuckAtConstant(T right, uint32_t min, uint32_t max, uint32_t current, bool isActive);

  // specializzazioni

  //bool stuckAt(bool& right, uint32_t min, uint32_t max, uint32_t current, bool isActive);
  bool stuckAt(bool right, uint32_t min, uint32_t max, uint32_t current, bool isActive);

  //sc_dt::sc_logic stuckAt(sc_dt::sc_logic& right, uint32_t min, uint32_t max, uint32_t current, bool isActive);
  sc_dt::sc_logic stuckAt(sc_dt::sc_logic right, uint32_t min, uint32_t max, uint32_t current, bool isActive);
}

}

#include "stuckAtLibrary.i.hh"

#endif
