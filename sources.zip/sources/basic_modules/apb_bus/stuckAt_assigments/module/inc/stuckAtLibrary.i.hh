/* Matteo Calabria */

#ifdef __GNUC__
#pragma GCC diagnostic ignored "-Wsign-conversion"
#endif

#ifndef STUCK_AT_MUT_LIBRARY_I_HH
#define STUCK_AT_MUT_LIBRARY_I_HH

#include "stuckAtLibrary.hh"

namespace splinter{

namespace mutationLibraries {

  //template<class T>
  //template<typename T, unsigned int W = 1>
  //template<typename T>
  //T stuckAt(T& right, uint32_t min, uint32_t max, uint32_t current, bool isActive)
  template<typename T>
  T stuckAt(T right, uint32_t min, uint32_t max, uint32_t current, bool isActive)
  {
    if ((current < min) || (current > max) || !isActive) return right;
    uint32_t index = (current - min) / 2L;
    T mask = static_cast<T>(1 << index);
    right ^= ( -((current&1)!=0) ^ right ) & mask;
    //if ( (current&1) == 0) // pari
    //{
    //    right &= static_cast<T>(~mask);
    //}
    //else
    //{
    //    right |= mask;
    //}
    return right;
  }

  template<typename T>
  T stuckAtConstant(T right, uint32_t min, uint32_t max, uint32_t current, bool isActive)
  {
    if ((current < min) || (current > max) || !isActive) return right;
    uint32_t index = (current - min);
    T mask = static_cast<T>(1 << index);
    right ^= mask;
    return right;
  }

}
}


#endif
