/* Matteo Calabria */

#include "../inc/stuckAtLibrary.hh"

namespace splinter{

namespace mutationLibraries{

  //bool stuckAt(bool& right, uint32_t min, uint32_t max, uint32_t current, bool isActive)
  bool stuckAt(bool right, uint32_t min, uint32_t max, uint32_t current, bool isActive)
  {
    if ((current < min) || (current > max) || !isActive) return right;
    if (current == min)
    {
        right = false;
    }
    else
    {
        right = true;
    }
    return right;
  }

  //sc_dt::sc_logic stuckAt(sc_dt::sc_logic& right, uint32_t min, uint32_t max, uint32_t current, bool isActive)
  sc_dt::sc_logic stuckAt(sc_dt::sc_logic right, uint32_t min, uint32_t max, uint32_t current, bool isActive)
  {
      if ((current < min) || (current > max) || !isActive) return right;
      if (current == min)
      {
          right = sc_dt::sc_logic('0');
      }
      else
      {
          right = sc_dt::sc_logic('1');
      }
      return right;
  }

}

}
