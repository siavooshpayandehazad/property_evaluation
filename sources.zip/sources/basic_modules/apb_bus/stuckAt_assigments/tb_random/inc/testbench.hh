#ifndef TESTBENCH_RANDOM__HH
#define TESTBENCH_RANDOM__HH

#include "../../../../../../utils/random/inc/Random.hh"

#define PERIOD 500

#include <systemc>

class testbench : public sc_core::sc_module {

  public:

    sc_core::sc_out< sc_dt::sc_logic > clk;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_master_pwdata;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_psel0;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_psel1;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_psel2;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_penable;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_pwrite;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_master_paddr;
    sc_core::sc_out< sc_dt::sc_logic > apb_master_presetn;

    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_master_prdata1;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_master_prdata2;
    sc_core::sc_in< sc_dt::sc_logic > apb_master_clk1;
    sc_core::sc_in< sc_dt::sc_logic > apb_master_clk2;

    sc_core::sc_in< sc_dt::sc_logic > apb_1_presetn1;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_presetn2;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_clk1;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_clk2;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_psel1;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_psel2;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_penable1;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_penable2;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_pwrite1;
    sc_core::sc_in< sc_dt::sc_logic > apb_1_pwrite2;
    sc_core::sc_in< sc_dt::sc_lv< 3L > > apb_1_paddr1;
    sc_core::sc_in< sc_dt::sc_lv< 3L > > apb_1_paddr2;
    sc_core::sc_out< sc_dt::sc_lv< 8L > > apb_1_prdata;
    sc_core::sc_in< sc_dt::sc_lv< 8L > > apb_1_pwdata1;
    sc_core::sc_in< sc_dt::sc_lv< 8L > > apb_1_pwdata2;


    sc_core::sc_in< sc_dt::sc_logic > apb_2_presetn1, apb_2_presetn2;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_clk1, apb_2_clk2;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_psel1, apb_2_psel2;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_penable1, apb_2_penable2;
    sc_core::sc_in< sc_dt::sc_logic > apb_2_pwrite1, apb_2_pwrite2;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_2_paddr1, apb_2_paddr2;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_2_prdata;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_2_pwdata1, apb_2_pwdata2;


    sc_core::sc_in< sc_dt::sc_logic > apb_3_presetn1, apb_3_presetn2;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_clk1, apb_3_clk2;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_psel1, apb_3_psel2;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_penable1, apb_3_penable2;
    sc_core::sc_in< sc_dt::sc_logic > apb_3_pwrite1, apb_3_pwrite2;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_3_paddr1, apb_3_paddr2;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > apb_3_prdata;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > apb_3_pwdata1, apb_3_pwdata2;

    sc_core::sc_out< uint32_t > splinterMutPort1, splinterMutPort2;
    sc_core::sc_out< bool > splinterEnableMutPort1, splinterEnableMutPort2;


    SC_HAS_PROCESS(testbench);
    testbench(sc_core::sc_module_name name_);
    ~testbench();

    void setLength (uint32_t sequences, uint32_t length);

    void setSeed(int seed);
    void setFault(uint32_t fault);

    bool isCaught();

  private:

    int _seed;
    uint32_t _sequences;
    uint32_t _length;
    uint32_t _fault;
    bool _found;

    void clk_gen();
    void run();

    void _areEqual();
};

#endif
