#include "../inc/testbench.hh"

#define OFFSET 5

// CONSTRUCTOR

testbench::testbench(sc_core::sc_module_name name)
  : clk("clk"),
    apb_master_pwdata("apb_master_pwdata"),
    apb_master_psel0("apb_master_psel0"),
    apb_master_psel1("apb_master_psel1"),
    apb_master_psel2("apb_master_psel2"),
    apb_master_penable("apb_master_penable"),
    apb_master_pwrite("apb_master_pwrite"),
    apb_master_paddr("apb_master_paddr"),
    apb_master_presetn("apb_master_presetn"),

    apb_master_prdata1("apb_master_prdata1"),
    apb_master_prdata2("apb_master_prdata2"),
    apb_master_clk1("apb_master_clk1"),
    apb_master_clk2("apb_master_clk2"),

    apb_1_presetn1("apb_1_presetn1"),
    apb_1_presetn2("apb_1_presetn2"),
    apb_1_clk1("apb_1_clk1"),
    apb_1_clk2("apb_1_clk2"),
    apb_1_psel1("apb_1_psel1"),
    apb_1_psel2("apb_1_psel2"),
    apb_1_penable1("apb_1_penable1"),
    apb_1_penable2("apb_1_penable2"),
    apb_1_pwrite1("apb_1_pwrite1"),
    apb_1_pwrite2("apb_1_pwrite2"),
    apb_1_paddr1("apb_1_paddr1"),
    apb_1_paddr2("apb_1_paddr2"),
    apb_1_prdata("apb_1_prdata"),
    apb_1_pwdata1("apb_1_pwdata1"),
    apb_1_pwdata2("apb_1_pwdata2"),

    apb_2_presetn1("apb_2_presetn1"),
    apb_2_presetn2("apb_2_presetn2"),
    apb_2_clk1("apb_2_clk1"),
    apb_2_clk2("apb_2_clk2"),
    apb_2_psel1("apb_2_psel1"),
    apb_2_psel2("apb_2_psel2"),
    apb_2_penable1("apb_2_penable1"),
    apb_2_penable2("apb_2_penable2"),
    apb_2_pwrite1("apb_2_pwrite1"),
    apb_2_pwrite2("apb_2_pwrite2"),
    apb_2_paddr1("apb_2_paddr1"),
    apb_2_paddr2("apb_2_paddr2"),
    apb_2_prdata("apb_2_prdata"),
    apb_2_pwdata1("apb_2_pwdata1"),
    apb_2_pwdata2("apb_2_pwdata2"),

    apb_3_presetn1("apb_3_presetn1"),
    apb_3_presetn2("apb_3_presetn2"),
    apb_3_clk1("apb_3_clk1"),
    apb_3_clk2("apb_3_clk2"),
    apb_3_psel1("apb_3_psel1"),
    apb_3_psel2("apb_3_psel2"),
    apb_3_penable1("apb_3_penable1"),
    apb_3_penable2("apb_3_penable2"),
    apb_3_pwrite1("apb_3_pwrite1"),
    apb_3_pwrite2("apb_3_pwrite2"),
    apb_3_paddr1("apb_3_paddr1"),
    apb_3_paddr2("apb_3_paddr2"),
    apb_3_prdata("apb_3_prdata"),
    apb_3_pwdata1("apb_3_pwdata1"),
    apb_3_pwdata2("apb_3_pwdata2"),

    splinterMutPort1("splinterMutPort1"),
    splinterMutPort2("splinterMutPort2"),
    splinterEnableMutPort1("splinterEnableMutPort1"),
    splinterEnableMutPort2("splinterEnableMutPort2"),
    _seed(1000),
    _sequences(10),
    _length(10000),
    _fault(0),
    _found(false)
{
  SC_THREAD(clk_gen);

  SC_THREAD(run);
  sensitive << clk.pos();
  dont_initialize();

  SC_METHOD(_areEqual);
  sensitive << clk.neg();
  dont_initialize();
}

// Destructor
testbench::~testbench()
{
  // Nothing to do
}

// Public methods
void testbench::setLength(uint32_t sequences, uint32_t length)
{
  _sequences = sequences;
  _length = length;
}

void testbench::setSeed(int seed)
{
  _seed = seed;
}

void testbench::setFault(uint32_t fault)
{
  _fault = fault;
}

// Private methods
void testbench::clk_gen()
{
  while (true)
  {
    clk.write(sc_dt::sc_logic('1'));
    wait(PERIOD / 2, sc_core::SC_NS);
    clk.write(sc_dt::sc_logic('0'));
    wait(PERIOD / 2, sc_core::SC_NS);
  }
}

void testbench::run()
{
  std::cout << "fault: " << _fault << std::endl;
  std::cout << "_sequences: " << _sequences << std::endl;
  std::cout << "_length: " << _length << std::endl;


  splinterEnableMutPort1.write(false);
  splinterEnableMutPort2.write(true);

  splinterMutPort1.write(0);
  splinterMutPort2.write(_fault);

  srand(_seed);

  bool exiting = false;
  for (uint32_t i = 0; i < _sequences; ++i)
  {
    for (uint32_t j = 0; j < _length; ++j)
    {
      // reset for devices (random)
      apb_master_presetn.write(utils::random::getRandomLogic());
      // enable for devices (random)
      apb_master_penable.write(utils::random::getRandomLogic());

      // psel
      apb_master_psel0.write(utils::random::getRandomLogic());
      apb_master_psel1.write(utils::random::getRandomLogic());
      apb_master_psel2.write(utils::random::getRandomLogic());

      // address
      apb_master_paddr.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));

      // read or write ?
      if (utils::random::getRandomBoolean()) // write
      {
          apb_master_pwdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
          apb_master_pwrite.write(sc_dt::sc_logic('1'));
          wait();
      }
      else // read
      {
          // random data for devices
          apb_1_prdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
          apb_2_prdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
          apb_3_prdata.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));

          apb_master_pwrite.write(sc_dt::sc_logic('0'));
          wait();
      }

      if (!exiting && _found)
      {
        std::cout << "Found :) " << std::endl;
        i = _sequences;
        j = _length - OFFSET;
        exiting = true;
      }
    }
  }

  sc_core::sc_stop();
}

void testbench::_areEqual()
{
  if (!_found)
    _found = (   (apb_master_prdata1.read() != apb_master_prdata2.read())
              || (apb_master_clk1.read() != apb_master_clk1.read())

              || (apb_1_presetn1.read() != apb_1_presetn2.read())
              || (apb_1_clk1.read() != apb_1_clk2.read())
              || (apb_1_psel1.read() != apb_1_psel2.read())
              || (apb_1_penable1.read() != apb_1_penable2.read())
              || (apb_1_pwrite1.read() != apb_1_pwrite2.read())
              || (apb_1_paddr1.read() != apb_1_paddr2.read())
              || (apb_1_pwdata1.read() != apb_1_pwdata2.read())

              || (apb_2_presetn1.read() != apb_2_presetn2.read())
              || (apb_2_clk1.read() != apb_2_clk2.read())
              || (apb_2_psel1.read() != apb_2_psel2.read())
              || (apb_2_penable1.read() != apb_2_penable2.read())
              || (apb_2_pwrite1.read() != apb_2_pwrite2.read())
              || (apb_2_paddr1.read() != apb_2_paddr2.read())
              || (apb_2_pwdata1.read() != apb_2_pwdata2.read())

              || (apb_3_presetn1.read() != apb_3_presetn2.read())
              || (apb_3_clk1.read() != apb_3_clk2.read())
              || (apb_3_psel1.read() != apb_3_psel2.read())
              || (apb_3_penable1.read() != apb_3_penable2.read())
              || (apb_3_pwrite1.read() != apb_3_pwrite2.read())
              || (apb_3_paddr1.read() != apb_3_paddr2.read())
              || (apb_3_pwdata1.read() != apb_3_pwdata2.read())
            );
}

bool testbench::isCaught()
{
  return _found;
}
