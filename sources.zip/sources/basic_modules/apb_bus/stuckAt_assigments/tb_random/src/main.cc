#include "../inc/testbench.hh"
#include "../../module/inc/apb_bus.hh"
#include <iostream>
#include <string>
#include <systemc.h>

int sc_main(int argc, char **argv)
{
  if (argc == 5)
  {
    // 1. Create testbench
    testbench testbench("testbench");
    testbench.setSeed(atoi(argv[1]));
    testbench.setLength(static_cast<uint32_t>(atoi(argv[2])),
                        static_cast<uint32_t>(atoi(argv[3])));
    testbench.setFault(static_cast<uint32_t>(atoi(argv[4])));

    // 2. Create design under test (dut)
    apb_bus design("design_under_test");
    apb_bus goldenModel("golden_model");

    // signal inputs
    sc_core::sc_signal< sc_dt::sc_logic > clk;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_master_pwdata;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_psel0;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_psel1;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_psel2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_penable;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_pwrite;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_master_paddr;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_presetn;

    sc_core::sc_signal< sc_dt::sc_lv< 8L > > apb_1_prdata;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_2_prdata;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_3_prdata;

    // signal outputs
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_master_prdata1, apb_master_prdata2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_master_clk1,        apb_master_clk2;

    sc_core::sc_signal< sc_dt::sc_logic > apb_1_presetn1,         apb_1_presetn2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_clk1,             apb_1_clk2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_psel1,            apb_1_psel2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_penable1,         apb_1_penable2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_1_pwrite1,          apb_1_pwrite2;
    sc_core::sc_signal< sc_dt::sc_lv< 3L > > apb_1_paddr1,        apb_1_paddr2;
    sc_core::sc_signal< sc_dt::sc_lv< 8L > > apb_1_pwdata1,       apb_1_pwdata2;

    sc_core::sc_signal< sc_dt::sc_logic > apb_2_presetn1,         apb_2_presetn2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_clk1,             apb_2_clk2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_psel1,            apb_2_psel2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_penable1,         apb_2_penable2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_2_pwrite1,          apb_2_pwrite2;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_2_paddr1,       apb_2_paddr2;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_2_pwdata1,      apb_2_pwdata2;

    sc_core::sc_signal< sc_dt::sc_logic > apb_3_presetn1,         apb_3_presetn2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_clk1,              apb_3_clk2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_psel1,             apb_3_psel2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_penable1,          apb_3_penable2;
    sc_core::sc_signal< sc_dt::sc_logic > apb_3_pwrite1,           apb_3_pwrite2;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_3_paddr1,        apb_3_paddr2;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > apb_3_pwdata1,       apb_3_pwdata2;

    sc_core::sc_signal< bool > splinterEnableMutPort1, splinterEnableMutPort2;
    sc_core::sc_signal< uint32_t > splinterMutPort1, splinterMutPort2;

    // outputs testbench
    testbench.clk(clk);
    testbench.apb_master_pwdata(apb_master_pwdata);
    testbench.apb_master_psel0(apb_master_psel0);
    testbench.apb_master_psel1(apb_master_psel1);
    testbench.apb_master_psel2(apb_master_psel2);
    testbench.apb_master_penable(apb_master_penable);
    testbench.apb_master_pwrite(apb_master_pwrite);
    testbench.apb_master_paddr(apb_master_paddr);
    testbench.apb_master_presetn(apb_master_presetn);
    testbench.apb_1_prdata(apb_1_prdata);
    testbench.apb_2_prdata(apb_2_prdata);
    testbench.apb_3_prdata(apb_3_prdata);

    testbench.splinterEnableMutPort1(splinterEnableMutPort1);
    testbench.splinterEnableMutPort2(splinterEnableMutPort2);
    testbench.splinterMutPort1(splinterMutPort1);
    testbench.splinterMutPort2(splinterMutPort2);

    // inputs goldemodel and faulty design
    goldenModel.clk(clk);                                 design.clk(clk);
    goldenModel.apb_master_pwdata(apb_master_pwdata);     design.apb_master_pwdata(apb_master_pwdata);
    goldenModel.apb_master_psel0(apb_master_psel0);       design.apb_master_psel0(apb_master_psel0);
    goldenModel.apb_master_psel1(apb_master_psel1);       design.apb_master_psel1(apb_master_psel1);
    goldenModel.apb_master_psel2(apb_master_psel2);       design.apb_master_psel2(apb_master_psel2);
    goldenModel.apb_master_penable(apb_master_penable);   design.apb_master_penable(apb_master_penable);
    goldenModel.apb_master_pwrite(apb_master_pwrite);     design.apb_master_pwrite(apb_master_pwrite);
    goldenModel.apb_master_paddr(apb_master_paddr);       design.apb_master_paddr(apb_master_paddr);
    goldenModel.apb_master_presetn(apb_master_presetn);   design.apb_master_presetn(apb_master_presetn);
    goldenModel.apb_1_prdata(apb_1_prdata);               design.apb_1_prdata(apb_1_prdata);
    goldenModel.apb_2_prdata(apb_2_prdata);               design.apb_2_prdata(apb_2_prdata);
    goldenModel.apb_3_prdata(apb_3_prdata);               design.apb_3_prdata(apb_3_prdata);

    goldenModel.splinterEnableMutPort(splinterEnableMutPort1);
                                                          design.splinterEnableMutPort(splinterEnableMutPort2);
    goldenModel.splinterMutPort(splinterMutPort1);        design.splinterMutPort(splinterMutPort2);

    // inputs testbench
    testbench.apb_master_prdata1(apb_master_prdata1);     testbench.apb_master_prdata2(apb_master_prdata2);
    testbench.apb_master_clk1(apb_master_clk1);           testbench.apb_master_clk2(apb_master_clk2);

    testbench.apb_1_presetn1(apb_1_presetn1);             testbench.apb_1_presetn2(apb_1_presetn2);
    testbench.apb_1_clk1(apb_1_clk1);                     testbench.apb_1_clk2(apb_1_clk2);
    testbench.apb_1_psel1(apb_1_psel1);                   testbench.apb_1_psel2(apb_1_psel2);
    testbench.apb_1_penable1(apb_1_penable1);             testbench.apb_1_penable2(apb_1_penable2);
    testbench.apb_1_pwrite1(apb_1_pwrite1);               testbench.apb_1_pwrite2(apb_1_pwrite2);
    testbench.apb_1_paddr1(apb_1_paddr1);                 testbench.apb_1_paddr2(apb_1_paddr2);
    testbench.apb_1_pwdata1(apb_1_pwdata1);               testbench.apb_1_pwdata2(apb_1_pwdata2);

    testbench.apb_2_presetn1(apb_2_presetn1);             testbench.apb_2_presetn2(apb_2_presetn2);
    testbench.apb_2_clk1(apb_2_clk1);                     testbench.apb_2_clk2(apb_2_clk2);
    testbench.apb_2_psel1(apb_2_psel1);                   testbench.apb_2_psel2(apb_2_psel2);
    testbench.apb_2_penable1(apb_2_penable1);             testbench.apb_2_penable2(apb_2_penable2);
    testbench.apb_2_pwrite1(apb_2_pwrite1);               testbench.apb_2_pwrite2(apb_2_pwrite2);
    testbench.apb_2_paddr1(apb_2_paddr1);                 testbench.apb_2_paddr2(apb_2_paddr2);
    testbench.apb_2_pwdata1(apb_2_pwdata1);               testbench.apb_2_pwdata2(apb_2_pwdata2);

    testbench.apb_3_presetn1(apb_3_presetn1);             testbench.apb_3_presetn2(apb_3_presetn2);
    testbench.apb_3_clk1(apb_3_clk1);                     testbench.apb_3_clk2(apb_3_clk2);
    testbench.apb_3_psel1(apb_3_psel1);                   testbench.apb_3_psel2(apb_3_psel2);
    testbench.apb_3_penable1(apb_3_penable1);             testbench.apb_3_penable2(apb_3_penable2);
    testbench.apb_3_pwrite1(apb_3_pwrite1);               testbench.apb_3_pwrite2(apb_3_pwrite2);
    testbench.apb_3_paddr1(apb_3_paddr1);                 testbench.apb_3_paddr2(apb_3_paddr2);
    testbench.apb_3_pwdata1(apb_3_pwdata1);               testbench.apb_3_pwdata2(apb_3_pwdata2);

    // outputs goldenModel and design
    goldenModel.apb_master_prdata(apb_master_prdata1);   design.apb_master_prdata(apb_master_prdata2);
    goldenModel.apb_master_clk(apb_master_clk1);         design.apb_master_clk(apb_master_clk2);

    goldenModel.apb_1_presetn(apb_1_presetn1);           design.apb_1_presetn(apb_1_presetn2);
    goldenModel.apb_1_clk(apb_1_clk1);                   design.apb_1_clk(apb_1_clk2);
    goldenModel.apb_1_psel(apb_1_psel1);                 design.apb_1_psel(apb_1_psel2);
    goldenModel.apb_1_penable(apb_1_penable1);           design.apb_1_penable(apb_1_penable2);
    goldenModel.apb_1_pwrite(apb_1_pwrite1);             design.apb_1_pwrite(apb_1_pwrite2);
    goldenModel.apb_1_paddr(apb_1_paddr1);               design.apb_1_paddr(apb_1_paddr2);
    goldenModel.apb_1_pwdata(apb_1_pwdata1);             design.apb_1_pwdata(apb_1_pwdata2);

    goldenModel.apb_2_presetn(apb_2_presetn1);           design.apb_2_presetn(apb_2_presetn2);
    goldenModel.apb_2_clk(apb_2_clk1);                   design.apb_2_clk(apb_2_clk2);
    goldenModel.apb_2_psel(apb_2_psel1);                 design.apb_2_psel(apb_2_psel2);
    goldenModel.apb_2_penable(apb_2_penable1);           design.apb_2_penable(apb_2_penable2);
    goldenModel.apb_2_pwrite(apb_2_pwrite1);             design.apb_2_pwrite(apb_2_pwrite2);
    goldenModel.apb_2_paddr(apb_2_paddr1);               design.apb_2_paddr(apb_2_paddr2);
    goldenModel.apb_2_pwdata(apb_2_pwdata1);             design.apb_2_pwdata(apb_2_pwdata2);

    goldenModel.apb_3_presetn(apb_3_presetn1);           design.apb_3_presetn(apb_3_presetn2);
    goldenModel.apb_3_clk(apb_3_clk1);                   design.apb_3_clk(apb_3_clk2);
    goldenModel.apb_3_psel(apb_3_psel1);                 design.apb_3_psel(apb_3_psel2);
    goldenModel.apb_3_penable(apb_3_penable1);           design.apb_3_penable(apb_3_penable2);
    goldenModel.apb_3_pwrite(apb_3_pwrite1);             design.apb_3_pwrite(apb_3_pwrite2);
    goldenModel.apb_3_paddr(apb_3_paddr1);               design.apb_3_paddr(apb_3_paddr2);
    goldenModel.apb_3_pwdata(apb_3_pwdata1);             design.apb_3_pwdata(apb_3_pwdata2);



    // 4. Trace the signals of interest
    sc_core::sc_trace_file * tf = sc_core::sc_create_vcd_trace_file("apb_faultyTrace");
    //sc_core::sc_trace_file * tf = sc_core::sc_create_vcd_trace_file(argv[4]);
    //tf->set_time_unit(PERIOD / 2, sc_core::SC_NS);
    sc_core::sc_trace(tf, design.clk, "clk");
    sc_core::sc_trace(tf, design.apb_master_prdata, "apb_master_prdata");
    sc_core::sc_trace(tf, design.apb_master_clk, "apb_master_clk");
    sc_core::sc_trace(tf, design.apb_master_pwdata, "apb_master_pwdata");
    sc_core::sc_trace(tf, design.apb_master_psel0, "apb_master_psel0");
    sc_core::sc_trace(tf, design.apb_master_psel1, "apb_master_psel1");
    sc_core::sc_trace(tf, design.apb_master_psel2, "apb_master_psel2");
    sc_core::sc_trace(tf, design.apb_master_penable, "apb_master_penable");
    sc_core::sc_trace(tf, design.apb_master_pwrite, "apb_master_pwrite");
    sc_core::sc_trace(tf, design.apb_master_paddr, "apb_master_paddr");
    sc_core::sc_trace(tf, design.apb_master_presetn, "apb_master_presetn");

    sc_core::sc_trace(tf, design.apb_1_presetn, "apb_1_presetn");
    sc_core::sc_trace(tf, design.apb_1_clk, "apb_1_clk");
    sc_core::sc_trace(tf, design.apb_1_psel, "apb_1_psel");
    sc_core::sc_trace(tf, design.apb_1_penable, "apb_1_penable");
    sc_core::sc_trace(tf, design.apb_1_pwrite, "apb_1_pwrite");
    sc_core::sc_trace(tf, design.apb_1_paddr, "apb_1_paddr");
    sc_core::sc_trace(tf, design.apb_1_pwdata, "apb_1_pwdata");
    sc_core::sc_trace(tf, design.apb_1_prdata, "apb_1_prdata");

    sc_core::sc_trace(tf, design.apb_2_presetn, "apb_2_presetn");
    sc_core::sc_trace(tf, design.apb_2_clk, "apb_2_clk");
    sc_core::sc_trace(tf, design.apb_2_psel, "apb_2_psel");
    sc_core::sc_trace(tf, design.apb_2_penable, "apb_2_penable");
    sc_core::sc_trace(tf, design.apb_2_pwrite, "apb_2_pwrite");
    sc_core::sc_trace(tf, design.apb_2_paddr, "apb_2_paddr");
    sc_core::sc_trace(tf, design.apb_2_pwdata, "apb_2_pwdata");
    sc_core::sc_trace(tf, design.apb_2_prdata, "apb_2_prdata");

    sc_core::sc_trace(tf, design.apb_3_presetn, "apb_3_presetn");
    sc_core::sc_trace(tf, design.apb_3_clk, "apb_3_clk");
    sc_core::sc_trace(tf, design.apb_3_psel, "apb_3_psel");
    sc_core::sc_trace(tf, design.apb_3_penable, "apb_3_penable");
    sc_core::sc_trace(tf, design.apb_3_pwrite, "apb_3_pwrite");
    sc_core::sc_trace(tf, design.apb_3_paddr, "apb_3_paddr");
    sc_core::sc_trace(tf, design.apb_3_pwdata, "apb_3_pwdata");
    sc_core::sc_trace(tf, design.apb_3_prdata, "apb_3_prdata");

    sc_core::sc_start();

    if (testbench.isCaught())
    {
      ofstream report;
      report.open ("faultCaught.txt");
      report << ' ';
      report.close();
    }

    return 0;
  }
  else
  {
    std::cout << "\nUse it in this way:" << std::endl << std::endl
              << "\t./apb_tb_random [seed] [sequence_number] [sequence_length] [fault_number]"
              << std::endl << std::endl;

    return 1;
  }
}
