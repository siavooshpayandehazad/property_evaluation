#ifndef TESTBENCH_RANDOM__HH
#define TESTBENCH_RANDOM__HH

#include "../../../../../../utils/random/inc/Random.hh"

#define PERIOD 500
#include <systemc>

class testbench : public sc_core::sc_module {

  public:

    sc_core::sc_out< sc_dt::sc_logic > clk;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > fp_a;
    sc_core::sc_out< sc_dt::sc_lv< 32L > > fp_b;
    sc_core::sc_in< sc_dt::sc_lv< 32L > > fp_z;
    
    SC_HAS_PROCESS(testbench);
    testbench(sc_core::sc_module_name name_);
    ~testbench();
    
    void set_length(unsigned int seed, unsigned int length);
      
    sc_core::sc_signal < float > float_a;
    sc_core::sc_signal < float > float_b;    
    sc_core::sc_signal < float > float_z;  
        
  private:

    unsigned int _seed;
    unsigned int _length;

    void update_a();
    void update_b();  
    void update_z();  

    void clk_gen();
    void run();
};

#endif

