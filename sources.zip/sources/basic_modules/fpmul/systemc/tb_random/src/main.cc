#include "../inc/testbench.hh"
#include "../../module/inc/fpmul.hh"
#include <iostream>

int sc_main(int argc, char **argv)
{
  if (argc == 3)
  {
    // 1. Create testbench
    testbench testbench("testbench");
    testbench.set_length(atoi(argv[1]), atoi(argv[2]));
    
    // 2. Create design under test (dut)
    fpmul design("design_under_test");
    
    // 3. Connect testbench and dut
    sc_core::sc_signal< sc_dt::sc_logic > clk;
    sc_core::sc_signal< sc_dt::sc_logic > add_sub;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_z;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_a;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_b;
    design.clk(clk);         testbench.clk(clk);    
    design.fp_a(fp_a);       testbench.fp_a(fp_a);
    design.fp_b(fp_b);       testbench.fp_b(fp_b);
    design.fp_z(fp_z);       testbench.fp_z(fp_z);
         
    // 4. Trace the signals of interest
    sc_core::sc_trace_file * tf = sc_core::sc_create_vcd_trace_file("fpmul_trace");
    tf->set_time_unit(PERIOD / 2, sc_core::SC_NS);
    sc_core::sc_trace(tf, design.clk, "clk");
    sc_core::sc_trace(tf, testbench.fp_a, "fp_a");
    sc_core::sc_trace(tf, testbench.fp_b, "fp_b");
    sc_core::sc_trace(tf, testbench.fp_z, "fp_z");
    
    #ifdef FLOAT_TRACE
      sc_core::sc_trace_file * tf2 = sc_core::sc_create_vcd_trace_file("fpmul_trace_float");
      tf2->set_time_unit(PERIOD / 2, sc_core::SC_NS);
      sc_core::sc_trace(tf2, design.clk, "clk");
      sc_core::sc_trace(tf2, testbench.float_a, "fp_a");
      sc_core::sc_trace(tf2, testbench.float_b, "fp_b");
      sc_core::sc_trace(tf2, testbench.float_z, "fp_z");
    #endif
    
    sc_core::sc_start(); return 0;
  }
  else
  {
    std::cout << "\nUse in one of the following ways:\n\n"
      << "   ./fpmul_tb_random [seed] [sequence_length]\n\n";
    return 1;
  }
}
