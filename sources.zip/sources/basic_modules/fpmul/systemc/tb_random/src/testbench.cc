#include "../inc/testbench.hh"

// CONSTRUCTOR

testbench::testbench(sc_core::sc_module_name name)
  : _seed(1000), _length(1000000)
{
  SC_THREAD(clk_gen);
  
  SC_THREAD(run);
  sensitive << clk;
	
  SC_METHOD(update_a);
  sensitive << fp_a;
  
  SC_METHOD(update_b);
  sensitive << fp_b;
  
  SC_METHOD(update_z);
  sensitive << fp_z; 
}

void testbench::update_a()
{
  unsigned long int value = fp_a.read().to_ulong();
  float_a.write(*(reinterpret_cast<float *>(&value)));
}

void testbench::update_b()
{
  unsigned long int value = fp_b.read().to_ulong();
  float_b.write(*(reinterpret_cast<float *>(&value)));
}

void testbench::update_z()
{
  unsigned long int value = fp_z.read().to_ulong();
  float_z.write(*(reinterpret_cast<float *>(&value)));
}

// Destructor

testbench::~testbench()
{
  // Nothing to do
}

// Public methods

void testbench::set_length(unsigned int seed, unsigned int length) 
{
  _seed = seed;
  _length = length;
}

// Private methods

void testbench::clk_gen() 
{
  while (true) 
  {
    clk.write(sc_dt::sc_logic('1'));
    wait(PERIOD / 2, sc_core::SC_NS);
    clk.write(sc_dt::sc_logic('0'));
    wait(PERIOD / 2, sc_core::SC_NS);
  }
}

void testbench::run()
{
  srand(_seed);

  for (int i = 0; i < _length; ++i) 
  {   
      fp_a.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
      fp_b.write(sc_dt::sc_lv<32>(utils::random::getRandom32Bits()));
      wait();
  }

  sc_core::sc_stop();
}
