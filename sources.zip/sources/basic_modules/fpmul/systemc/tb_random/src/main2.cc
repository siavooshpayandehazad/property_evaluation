#include "../inc/testbench.hh"
#include "../../module/inc/fpmul.hh"
#include <iostream>

int sc_main(int argc, char **argv)
{
  if (argc == 3)
  {
    // 1. Create testbench
    testbench testbench("testbench");
    testbench.set_length(atoi(argv[1]), atoi(argv[2]));
    
    // 2. Create design under test (dut)
    fpmul design("design_under_test");
    
    // 3. Connect testbench and dut
    sc_core::sc_signal< sc_dt::sc_logic > clk;
    sc_core::sc_signal< sc_dt::sc_logic > add_sub;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_z;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_a;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_b;
    design.clk(clk);         testbench.clk(clk);    
    design.fp_a(fp_a);       testbench.fp_a(fp_a);
    design.fp_b(fp_b);       testbench.fp_b(fp_b);
    design.fp_z(fp_z);       testbench.fp_z(fp_z);
         
    // 4. Trace the signals of interest
    sc_core::sc_trace_file * tf_numeric = sc_core::sc_create_vcd_trace_file("fpmul_numeric");
    sc_core::sc_trace_file * tf_boolean = sc_core::sc_create_vcd_trace_file("fpmul_boolean");
    tf_numeric->set_time_unit(PERIOD / 2, sc_core::SC_NS); 
    tf_boolean->set_time_unit(PERIOD / 2, sc_core::SC_NS);
    
    // 4.1. Trace numeric signals
    
    // 4.1.1. Module: fpmul
    // sc_core::sc_trace(tf_numeric, testbench.float_a, "float_a"); // float
    // sc_core::sc_trace(tf_numeric, testbench.float_b, "float_b"); // float
    // sc_core::sc_trace(tf_numeric, testbench.float_z, "float_z"); // float             
    sc_core::sc_trace(tf_numeric, design.a_exp, "a_exp");
    sc_core::sc_trace(tf_numeric, design.a_sig, "a_sig");
    sc_core::sc_trace(tf_numeric, design.b_exp, "b_exp");
    sc_core::sc_trace(tf_numeric, design.b_sig, "b_sig");
    sc_core::sc_trace(tf_numeric, design.exp_in, "exp_in");
    sc_core::sc_trace(tf_numeric, design.sig_in, "sig_in");
    sc_core::sc_trace(tf_numeric, design.exp_out_round, "exp_out_round");
    sc_core::sc_trace(tf_numeric, design.sig_out_round, "sig_out_round");
    
    // 4.1.2. Module: unpackfp (i0)
    sc_core::sc_trace(tf_numeric, design.i1.i0.sig, "i1.i0.sig");
    sc_core::sc_trace(tf_numeric, design.i1.i0.exp, "i1.i0.exp");
    sc_core::sc_trace(tf_numeric, design.i1.i0.exp_int, "i1.i0.exp_int");
    sc_core::sc_trace(tf_numeric, design.i1.i0.sig_int, "i1.i0.sig_int");
   
    // 4.1.2. Module: unpackfp (i1)
    sc_core::sc_trace(tf_numeric, design.i1.i1.sig, "i1.i1.sig");
    sc_core::sc_trace(tf_numeric, design.i1.i1.exp, "i1.i1.exp");
    sc_core::sc_trace(tf_numeric, design.i1.i1.exp_int, "i1.i1.exp_int");
    sc_core::sc_trace(tf_numeric, design.i1.i1.sig_int, "i1.i1.sig_int"); 

    // 4.1.3. Module: fpnormalize (i9)
    sc_core::sc_trace(tf_numeric, design.i3.i9.sig_in, "i3.i9.sig_in");
    sc_core::sc_trace(tf_numeric, design.i3.i9.exp_in, "i3.i9.exp_in");
    sc_core::sc_trace(tf_numeric, design.i3.i9.sig_out, "i3.i9.sig_out");
    sc_core::sc_trace(tf_numeric, design.i3.i9.exp_out, "i3.i9.exp_out");

    // 4.1.4. Module: fpround (i11)
    sc_core::sc_trace(tf_numeric, design.i3.i11.sig_in, "i3.i11.sig_in");
    sc_core::sc_trace(tf_numeric, design.i3.i11.exp_in, "i3.i11.exp_in");
    sc_core::sc_trace(tf_numeric, design.i3.i11.sig_out, "i3.i11.sig_out");
    sc_core::sc_trace(tf_numeric, design.i3.i11.exp_out, "i3.i11.exp_out");

    // 4.1.5. Module: fpround (i1)
    sc_core::sc_trace(tf_numeric, design.i4.i1.sig_in, "i4.i1.sig_in");
    sc_core::sc_trace(tf_numeric, design.i4.i1.exp_in, "i4.i1.exp_in");
    sc_core::sc_trace(tf_numeric, design.i4.i1.sig_out, "i4.i1.sig_out");
    sc_core::sc_trace(tf_numeric, design.i4.i1.exp_out, "i4.i1.exp_out");
    
    // 4.1.6. Module: packfp (i3)
    sc_core::sc_trace(tf_numeric, design.i4.i3.exp, "i4.i3.exp");
    sc_core::sc_trace(tf_numeric, design.i4.i3.sig, "i4.i3.sig");

    // 4.2. Trace boolean signals
    
    // 4.2.1. Module: fpmul
    // sc_core::sc_trace(tf_boolean, design.clk, "fpmul.clk");
    sc_core::sc_trace(tf_boolean, design.exp_neg, "fpmul.exp_neg");
    sc_core::sc_trace(tf_boolean, design.exp_neg_stage2, "fpmul.exp_neg_stage2");
    sc_core::sc_trace(tf_boolean, design.exp_pos, "fpmul.exp_pos");
    sc_core::sc_trace(tf_boolean, design.exp_pos_stage2, "fpmul.exp_pos_stage2");
    sc_core::sc_trace(tf_boolean, design.sign_out, "fpmul.sign_out");
    sc_core::sc_trace(tf_boolean, design.sign_out_stage1, "fpmul.sign_out_stage1");
    sc_core::sc_trace(tf_boolean, design.sign_out_stage2, "fpmul.sign_out_stage2");
    sc_core::sc_trace(tf_boolean, design.isinf_stage1, "fpmul.isinf_stage1");
    sc_core::sc_trace(tf_boolean, design.isinf_stage2, "fpmul.isinf_stage2");
    sc_core::sc_trace(tf_boolean, design.isinf_tab, "fpmul.isinf_tab");
    sc_core::sc_trace(tf_boolean, design.isnan,  "fpmul.isnan");
    sc_core::sc_trace(tf_boolean, design.isnan_stage1, "fpmul.isnan_stage1");
    sc_core::sc_trace(tf_boolean, design.isnan_stage2, "fpmul.isnan_stage2");
    sc_core::sc_trace(tf_boolean, design.isz_tab, "fpmul.isz_tab");
    sc_core::sc_trace(tf_boolean, design.isz_tab_stage1, "fpmul.isz_tab_stage1");
    sc_core::sc_trace(tf_boolean, design.isz_tab_stage2, "fpmul.isz_tab_stage2");
   
    // 4.1.2. Module: unpackfp (i0)
    sc_core::sc_trace(tf_boolean, design.i1.i0.sign, "i1.i0.sign");
    sc_core::sc_trace(tf_boolean, design.i1.i0.isnan, "i1.i0.isnan");
    sc_core::sc_trace(tf_boolean, design.i1.i0.isinf, "i1.i0.isinf");
    sc_core::sc_trace(tf_boolean, design.i1.i0.isz, "i1.i0.isz");
    sc_core::sc_trace(tf_boolean, design.i1.i0.isdn, "i1.i0.isdn");
    // sc_core::sc_trace(tf_boolean, design.i1.i0.sig_mspw, "i1.i0.sig_mspw");
    sc_core::sc_trace(tf_boolean, design.i1.i0.expz, "i1.i0.expz");
    sc_core::sc_trace(tf_boolean, design.i1.i0.expff, "i1.i0.expff");
    sc_core::sc_trace(tf_boolean, design.i1.i0.sigz, "i1.i0.sigz");
   
    // 4.1.3. Module: unpackfp (i1)
    sc_core::sc_trace(tf_boolean, design.i1.i1.sign, "i1.i1.sign");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isnan, "i1.i1.isnan");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isinf, "i1.i1.isinf");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isz, "i1.i1.isz");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isdn, "i1.i1.isdn");
    // sc_core::sc_trace(tf_boolean, design.i1.i1.sig_mspw, "i1.i1.sig_mspw");
    sc_core::sc_trace(tf_boolean, design.i1.i1.expz, "i1.i1.expz");
    sc_core::sc_trace(tf_boolean, design.i1.i1.expff, "i1.i1.expff");
    sc_core::sc_trace(tf_boolean, design.i1.i1.sigz, "i1.i1.sigz");
   
    // 4.1.6. Module: packfp (i3)
    sc_core::sc_trace(tf_boolean, design.i4.i3.sign, "i4.i3.sign");
    sc_core::sc_trace(tf_boolean, design.i4.i3.isnan, "i4.i3.isnan"); 
    sc_core::sc_trace(tf_boolean, design.i4.i3.isinf, "i4.i3.isinf");
    sc_core::sc_trace(tf_boolean, design.i4.i3.isz, "i4.i3.isz");
  
    sc_core::sc_start(); 
    
    sc_core::sc_close_vcd_trace_file(tf_numeric);
    sc_core::sc_close_vcd_trace_file(tf_boolean);
       
    return 0;
  }
  else
  {
    std::cout << "\nUse in one of the following ways:\n\n"
      << "   ./run.x [seed] [sequence_length]\n\n";
    return 1;
  }
}
