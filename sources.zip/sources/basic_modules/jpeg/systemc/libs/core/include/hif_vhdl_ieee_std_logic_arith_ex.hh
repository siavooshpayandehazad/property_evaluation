#ifndef HIF_VHDL_IEEE_STD_LOGIC_ARITH_EX__HH
#define HIF_VHDL_IEEE_STD_LOGIC_ARITH_EX__HH

#include "hif2scSupport/config.hh"

namespace hif_vhdl_ieee_std_logic_arith_ex {


} // hif_vhdl_ieee_std_logic_arith_ex

#endif // HIF_VHDL_IEEE_STD_LOGIC_ARITH_EX__HH
