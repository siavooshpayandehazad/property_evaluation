// /////////////////////////////////////////////////////////////
// Copyright (C) 2013
// EDALab S.r.l.
// All rights reserved.
//
// This file is part of hif2scSupport.
//
// hif2scSupport is closed non-free software:
// you can use it only with written license permission.
// If you have not a license, please delete this file.
//
// hif2scSupport is distributed WITHOUT ANY WARRANTY.
// See the License for more details.
//
// You should have received a copy of the License along with
// hif2scSupport, in a file named LICENSE.txt.
// /////////////////////////////////////////////////////////////


#ifndef HIF_SYSTEMC_EXTENSIONS_hif_assign_I_HH
#define HIF_SYSTEMC_EXTENSIONS_hif_assign_I_HH

#include "hif_assign.hh"

namespace hif_systemc_extensions {


    // /////////////////////////////////////////////////////////////////////////
    // Base case.
    // /////////////////////////////////////////////////////////////////////////

    template< typename T, typename S >
    void hif_assign( T& target, const S& source )
    {
        target = source;
    }

    template< typename S >
    void hif_assign( bool& target, const sc_dt::sc_bitref<S>& source )
    {
        target = source.to_bool();
    }

    template< typename S >
    void hif_assign( sc_core::sc_signal<bool>& target, const sc_dt::sc_bitref<S>& source )
    {
        target = source.to_bool();
    }

    template< typename S >
    void hif_assign( sc_core::sc_out<bool>& target, const sc_dt::sc_bitref<S>& source )
    {
        target = source.to_bool();
    }

    template< typename S >
    void hif_assign( sc_core::sc_inout<bool>& target, const sc_dt::sc_bitref<S>& source )
    {
        target = source.to_bool();
    }

    template< typename T, typename S >
    void hif_assign( T& target, const sc_core::sc_signal< S >& source )
    {
        hif_assign( target, source.read());
    }

    template< typename T, typename S >
    void hif_assign( T& target, const sc_core::sc_in< S >& source )
    {
        hif_assign( target, source.read());
    }

    template< typename T, typename S >
    void hif_assign( T& target, const sc_core::sc_inout< S >& source )
    {
        hif_assign( target, source.read());
    }


    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////
    // Mono-dimensional.
    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////


    // /////////////////////////////////////////////////////////////////////////
    // Target is not array. Source is array.
    // /////////////////////////////////////////////////////////////////////////


    template< class T >
    struct TemporaryType
    {
        typedef T type;
    };


    template< int S >
    struct TemporaryType< sc_dt::sc_bv< S > >
    {
        typedef sc_dt::sc_logic type;
    };


    template< int S >
    struct TemporaryType< sc_dt::sc_lv< S > >
    {
        typedef sc_dt::sc_logic type;
    };


#ifdef HIF_USE_HDTLIB
    template< int S >
    struct TemporaryType< hdtlib::hl_bv_t< S > >
    {
        typedef bool type;
    };


    template< int S >
    struct TemporaryType< hdtlib::hl_lv_t< S > >
    {
        typedef hdtlib::hl_logic_t type;
    };


#endif //HIF_USE_HDTLIB


    template< typename T, typename S >
    void hif_assign( T& target, S source[],
            unsigned int size, unsigned int left, unsigned int right )
    {
        if (left == static_cast<unsigned int>(-1)) left = 0;
        const int min = left < right ? left : right;

        // Workaround to avoid needing of const references.
        typename TemporaryType< T >::type tmp;
        for( unsigned int i = 0; i < size; ++i )
        {
            // Call recursive case with less dimension (base).
            hif_assign( tmp, source[i] );
            target.set_bit(i+min, to_bit(tmp));
        }
    }

    template< typename T, typename S >
    void hif_assign( sc_core::sc_signal< T >& target, S source[],
            unsigned int size, unsigned int left, unsigned int right )
    {
        T tmp = target.read();
        // Call recursive case with less dimension (base).
        hif_assign( tmp, source, size, left, right );
        target.write( tmp );
    }


    template< typename T, typename S >
    void hif_assign( sc_core::sc_out< T >& target, S source[],
            unsigned int size, unsigned int left, unsigned int right )
    {
        T tmp = target.read();
        // Call recursive case with less dimension (base).
        hif_assign( tmp, source, size, left, right );
        target.write( tmp );
    }


    template< typename T, typename S >
    void hif_assign( sc_core::sc_inout< T >& target, S source[],
            unsigned int size, unsigned int left, unsigned int right )
    {
        T tmp = target.read();
        // Call recursive case with less dimension (base).
        hif_assign( tmp, source, size, left, right );
        target.write( tmp );
    }



    // /////////////////////////////////////////////////////////////////////////
    // Target is array. Source is not array.
    // /////////////////////////////////////////////////////////////////////////

    template< typename T, typename S >
    void hif_assign( T target[], S source,
            unsigned int size, unsigned int left, unsigned int right )
    {
        if (left == static_cast<unsigned int>(-1)) left = 0;
        const int min = left < right ? left : right;

        for (unsigned int i = 0; i < size; ++i)
        {
            // Call recursive case with less dimension (base).
            hif_assign( target[i+min], source[i] );
        }
    }


    template< typename T, typename S >
    void hif_assign( T target[], sc_core::sc_signal< S > source,
            unsigned int size, unsigned int left, unsigned int right )
    {
        if (left == static_cast<unsigned int>(-1)) left = 0;
        const int min = left < right ? left : right;

        for (unsigned int i = 0; i < size; ++i)
        {
            // Call recursive case with less dimension (base).
            hif_assign( target[i+min], source.read()[i] );
        }
    }


    template< typename T, typename S >
    void hif_assign( T target[], sc_core::sc_in< S > source,
            unsigned int size, unsigned int left, unsigned int right )
    {
        if (left == static_cast<unsigned int>(-1)) left = 0;
        const int min = left < right ? left : right;

        for (unsigned int i = 0; i < size; ++i)
        {
            // Call recursive case with less dimension (base).
            hif_assign( target[i+min], source.read()[i] );
        }
    }


    template< typename T, typename S >
    void hif_assign( T target[], sc_core::sc_inout< S > source,
            unsigned int size, unsigned int left, unsigned int right )
    {
        if (left == static_cast<unsigned int>(-1)) left = 0;
        const int min = left < right ? left : right;

        for (unsigned int i = 0; i < size; ++i)
        {
            // Call recursive case with less dimension (base).
            hif_assign( target[i+min], source.read()[i] );
        }
    }



    // /////////////////////////////////////////////////////////////////////////
    // Target is array. Source is array.
    // /////////////////////////////////////////////////////////////////////////

    template< typename T, typename S >
    void hif_assign( T target[], S source[],
            unsigned int size, unsigned int left, unsigned int right )
    {
        if (left == static_cast<unsigned int>(-1)) left = 0;
        const int min = left < right ? left : right;

        for( unsigned int i = 0; i < size; ++i )
        {
            // Call recursive case with less dimension (no array, no array).
            hif_assign( target[i+min], source[i] );
        }
    }



    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////
    // Bi-dimensional.
    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////


    // /////////////////////////////////////////////////////////////////////////
    // Target is mono-array. Source is multi-array.
    // /////////////////////////////////////////////////////////////////////////

    template< typename T, typename S, unsigned int ssize >
    void hif_assign( T target[], S source[][ssize],
            unsigned int size,
            unsigned int left1, unsigned int right1,
            unsigned int left2, unsigned int right2 )
    {
        if (left1 == static_cast<unsigned int>(-1)) left1 = 0;
        const int min1 = left1 < right1 ? left1 : right1;

        // Cycling on the rows (1st dimension).
        for (unsigned int i = 0; i < size; ++i)
        {
            // Call recursive case with less dimension (no array, array).
            hif_assign( target[i+min1], source[i], ssize, left2, right2 );
        }
    }


    // /////////////////////////////////////////////////////////////////////////
    // Target is multi-array. Source is mono-array.
    // /////////////////////////////////////////////////////////////////////////

    template< typename T, typename S, unsigned int tsize >
    void hif_assign( T target[][tsize], S source[],
            unsigned int size,
            unsigned int left1, unsigned int right1,
            unsigned int left2, unsigned int right2 )
    {
        if (left1 == static_cast<unsigned int>(-1)) left1 = 0;
        const int min1 = left1 < right1 ? left1 : right1;

        // Cycling on the rows (1st dimension).
        for (unsigned int i = 0; i < size; ++i)
        {
            // Call recursive case with less dimension (array, no array).
            hif_assign( target[i+min1], source[i], source[i].length(), left2, right2 );
        }
    }


    template< typename T, typename S, unsigned int tsize >
    void hif_assign( T target[][tsize], S source,
            unsigned int size,
            unsigned int left1, unsigned int right1,
            unsigned int left2, unsigned int right2 )
    {
        if (left1 == static_cast<unsigned int>(-1)) left1 = 0;
        const int min1 = left1 < right1 ? left1 : right1;

        hif_assign( target[min1], source, source.length(), left2, right2 );
    }


    // /////////////////////////////////////////////////////////////////////////
    // Target is multi-array. Source is multi-array.
    // /////////////////////////////////////////////////////////////////////////

    template< typename T, typename S, unsigned int tsize, unsigned int ssize >
    void hif_assign( T target[][tsize], S source[][ssize],
            unsigned int size, unsigned int left1, unsigned int right1,
            unsigned int left2, unsigned int right2 )
    {
        if (left1 == static_cast<unsigned int>(-1)) left1 = 0;
        const int min1 = left1 < right1 ? left1 : right1;

        // Cycling on the rows (1st dimension).
        for (unsigned int i = 0; i < size; ++i)
        {
            // Call recursive case with less dimension (array, array).
            hif_assign( target[i+min1], source[i], ssize, left2, right2 );
        }
    }


} // namespace hif2scSupport


#endif //HIF_SYSTEMC_EXTENSIONS_hif_assign_I_HH
