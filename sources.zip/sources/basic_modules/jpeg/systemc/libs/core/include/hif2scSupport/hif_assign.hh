// /////////////////////////////////////////////////////////////
// Copyright (C) 2013
// EDALab S.r.l.
// All rights reserved.
//
// This file is part of hif2scSupport.
//
// hif2scSupport is closed non-free software:
// you can use it only with written license permission.
// If you have not a license, please delete this file.
//
// hif2scSupport is distributed WITHOUT ANY WARRANTY.
// See the License for more details.
//
// You should have received a copy of the License along with
// hif2scSupport, in a file named LICENSE.txt.
// /////////////////////////////////////////////////////////////

#ifndef HIF_SYSTEMC_EXTENSIONS_hif_assign_HH
#define HIF_SYSTEMC_EXTENSIONS_hif_assign_HH


#include "config.hh"


/////////////////////////////////////////
// Declarations
/////////////////////////////////////////

namespace hif_systemc_extensions {

// /////////////////////////////////////////////////////////////////////////
// Support methods for hif_assign.
// /////////////////////////////////////////////////////////////////////////

HIF2SCSUPPORT_EXPORT
sc_dt::sc_logic_value_t to_bit(sc_dt::sc_logic v);

HIF2SCSUPPORT_EXPORT
sc_dt::sc_logic_value_t to_bit(sc_dt::sc_bit v);

#ifdef HIF_USE_HDTLIB

HIF2SCSUPPORT_EXPORT
hdtlib::hl_logic_t to_bit(hdtlib::hl_logic_t v);

HIF2SCSUPPORT_EXPORT
bool to_bit(bool v);

#endif // HIF_USE_HDTLIB

/// @name This set of methods is intended as a way to assign a <N>-dimensional
/// source to a <M>-dimensional target, where source and target could have
/// SystemC types or native types.
/// It also allow to assign a specific portion of the source or target,
/// depending on which one is defined as multi-dimensional object.
///
/// @n All methods shown the following form:
/// @begin code
/// template< typename T, typename S >
/// void hif_assign( T& target, S source,
///        unsigned int size, unsigned int left, unsigned int right );
/// @end code
///
/// Where T and S indicate generic types for the target and the source.
/// @param target represents the target.
/// @param source represents the source.
/// @param size indicates the size of the multi-dimensional parameter (or   // TODO check
/// both, since they must be equal wrt to HIF assignment assumptions).
/// @param left indicates the left bound of the portion to be assigned (if any).
/// @param right indicates the right bound of the portion to be assigned (if any).
///
//@{


// /////////////////////////////////////////////////////////////////////////
// Base case.
// /////////////////////////////////////////////////////////////////////////


template< typename T, typename S >
void hif_assign( T& target, const S& source );

template< typename S >
void hif_assign( bool& target, const sc_dt::sc_bitref<S>& source );

template< typename S >
void hif_assign( sc_core::sc_signal<bool>& target, const sc_dt::sc_bitref<S>& source );

template< typename S >
void hif_assign( sc_core::sc_out<bool>& target, const sc_dt::sc_bitref<S>& source );

template< typename S >
void hif_assign( sc_core::sc_inout<bool>& target, const sc_dt::sc_bitref<S>& source );

template< typename T, typename S >
void hif_assign( T& target, const sc_core::sc_signal< S >& source );

template< typename T, typename S >
void hif_assign( T& target, const sc_core::sc_in< S >& source );

template< typename T, typename S >
void hif_assign( T& target, const sc_core::sc_inout< S >& source );


// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// Mono-dimensional.
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////
// Target is not array. Source is array.
// /////////////////////////////////////////////////////////////////////////

// size is dimension of source

template< typename T, typename S >
void hif_assign( T& target, S source[],
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );


template< typename T, typename S >
void hif_assign( sc_core::sc_signal< T >& target, S source[],
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );


template< typename T, typename S >
void hif_assign( sc_core::sc_out< T >& target, S source[],
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );


template< typename T, typename S >
void hif_assign( sc_core::sc_inout< T >& target, S source[],
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );



// /////////////////////////////////////////////////////////////////////////
// Target is array. Source is not array.
// /////////////////////////////////////////////////////////////////////////

// size is dimension of target

template< typename T, typename S >
void hif_assign( T target[], S source,
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );


template< typename T, typename S >
void hif_assign( T target[], sc_core::sc_signal< S > source,
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );


template< typename T, typename S >
void hif_assign( T target[], sc_core::sc_in< S > source,
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );


template< typename T, typename S >
void hif_assign( T target[], sc_core::sc_inout< S > source,
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );



// /////////////////////////////////////////////////////////////////////////
// Target is array. Source is array.
// /////////////////////////////////////////////////////////////////////////

// size is dimension of both source and target

template< typename T, typename S >
void hif_assign( T target[], S source[],
    unsigned int size, unsigned int left = static_cast<unsigned int>(-1),
    unsigned int right = static_cast<unsigned int>(-1) );


// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// Bi-dimensional.
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////
// Target is mono-array. Source is multi-array.
// /////////////////////////////////////////////////////////////////////////

template< typename T, typename S, unsigned int ssize >
void hif_assign( T target[], S source[][ssize],
    unsigned int size,
    unsigned int left1 = static_cast<unsigned int>(-1),
    unsigned int right1 = static_cast<unsigned int>(-1),
    unsigned int left2 = static_cast<unsigned int>(-1),
    unsigned int right2 = static_cast<unsigned int>(-1) );


// /////////////////////////////////////////////////////////////////////////
// Target is multi-array. Source is mono-array.
// /////////////////////////////////////////////////////////////////////////


template< typename T, typename S, unsigned int tsize >
void hif_assign( T target[][tsize], S source[],
    unsigned int size, unsigned int left1 = static_cast<unsigned int>(-1),
    unsigned int right1 = static_cast<unsigned int>(-1),
    unsigned int left2 = static_cast<unsigned int>(-1),
    unsigned int right2 = static_cast<unsigned int>(-1) );

template< typename T, typename S, unsigned int tsize >
void hif_assign( T target[][tsize], S source,
    unsigned int size, unsigned int left1 = static_cast<unsigned int>(-1),
    unsigned int right1 = static_cast<unsigned int>(-1),
    unsigned int left2 = static_cast<unsigned int>(-1),
    unsigned int right2 = static_cast<unsigned int>(-1) );



// /////////////////////////////////////////////////////////////////////////
// Target is multi-array. Source is multi-array.
// /////////////////////////////////////////////////////////////////////////

/// @brief Bidimensional matrix assign.
/// @param target The target of assign.
/// @param source The source of assign.
/// @param size is the length of the 1st dimension of source.
/// @param left1 is the eventual slice left bound of the 1st dimension of target.
/// @param right1 is the eventual slice right bound of the 1st dimension of target.
/// @param left2 is the eventual slice left bound of the 2nd dimension of target.
/// @param right2 is the eventual slice right bound of the 2nd dimension of target.
template< typename T, typename S, unsigned int tsize, unsigned int ssize >
void hif_assign( T target[][tsize], S source[][ssize],
    unsigned int size, unsigned int left1 = static_cast<unsigned int>(-1),
    unsigned int right1 = static_cast<unsigned int>(-1),
    unsigned int left2 = static_cast<unsigned int>(-1),
    unsigned int right2 = static_cast<unsigned int>(-1) );



// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// Multi-dimensional.
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////

// TODO


//@}

} // namespace hif2scSupport

/////////////////////////////////////////
// Template-implementation header
/////////////////////////////////////////

#include "hif_assign.i.hh"


#endif //HIF_SYSTEMC_EXTENSIONS_hif_assign_HH
