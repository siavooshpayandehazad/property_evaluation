#ifndef HIF_VHDL_IEEE_NUMERIC_BIT__HH
#define HIF_VHDL_IEEE_NUMERIC_BIT__HH

#include "hif2scSupport/config.hh"

namespace hif_vhdl_ieee_numeric_bit {


} // hif_vhdl_ieee_numeric_bit

#endif // HIF_VHDL_IEEE_NUMERIC_BIT__HH
