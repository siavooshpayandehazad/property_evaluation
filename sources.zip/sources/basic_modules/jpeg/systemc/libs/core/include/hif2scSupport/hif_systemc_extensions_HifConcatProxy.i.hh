#ifndef HIF_SYSTEMC_EXTENSIONS_CONCAT_PROXY__I_HH
#define HIF_SYSTEMC_EXTENSIONS_CONCAT_PROXY__I_HH


#include "hif2scSupport/config.hh"

namespace hif_systemc_extensions {

template<class T1, class T2>
HifConcatProxy<T1,T2>::HifConcatProxy(const T1 & t1, const T2 & t2):
    _t1(t1),
    _t2(t2)
{
    // ntd
}

template<class T1, class T2>
HifConcatProxy<T1,T2>::~HifConcatProxy()
{
    // ntd
}

template<class T1, class T2>
HifConcatProxy<T1,T2>::HifConcatProxy(const HifConcatProxy<T1,T2> & other):
    _t1(other._t1),
    _t2(other._t2)
{
    // ntd
}


template<class T1, class T2>
template<typename T3>
HifConcatProxy<T1,T2> & HifConcatProxy<T1,T2>::operator = (T3 t)
{
    int size = SIZE;
    if (size == -1) size = _getSize(_t2);
    T1 * trick1 = const_cast<T1*>(&_t1);
    _assign(*trick1, t.range(t.length() -1, size));
    T2 * trick2 = const_cast<T2*>(&_t2);
    _assign(*trick2, t.range(size -1, 0));
    return *this;
}

#ifdef HIF_USE_HDTLIB

template<class T1, class T2>
template<int W>
HifConcatProxy<T1,T2> & HifConcatProxy<T1,T2>::operator = (hdtlib::hl_lv_t<W> t)
{
    T1 * trick1 = const_cast<T1*>(&_t1);
    _assign(*trick1, t.template range<W - SIZE>(W -1, SIZE));
    T2 * trick2 = const_cast<T2*>(&_t2);
    _assign(*trick2, t.template range<SIZE>(SIZE -1, 0));
    return *this;
}

template<class T1, class T2>
template<int W>
HifConcatProxy<T1,T2> & HifConcatProxy<T1,T2>::operator = (hdtlib::hl_bv_t<W> t)
{
    T1 * trick1 = const_cast<T1*>(&_t1);
    _assign(*trick1, t.range<W - SIZE>(W -1, SIZE));
    T2 * trick2 = const_cast<T2*>(&_t2);
    _assign(*trick2, t.range<SIZE>(SIZE -1, 0));
    return *this;
}

#endif


template< typename T1, typename T2 >
template<typename S>
void HifConcatProxy<T1,T2>::_assign( sc_dt::sc_logic &t, S s)
{
    // base SystemC type case:
    t = s.to_string()[0];
}

template< typename T1, typename T2 >
template<typename S>
void HifConcatProxy<T1,T2>::_assign( sc_dt::sc_bit &t, S s)
{
    // base SystemC type case:
    t = s.to_string()[0];
}

template< typename T1, typename T2 >
template< typename S>
void HifConcatProxy<T1,T2>::_assign( bool &t, S s)
{
    t = s.to_string()[0];
}

template< typename T1, typename T2 >
template< int i, typename S>
void HifConcatProxy<T1,T2>::_assign( sc_dt::sc_lv<i> &t, S s)
{
    t = s;
}

template< typename T1, typename T2 >
template< int i, typename S>
void HifConcatProxy<T1,T2>::_assign( sc_dt::sc_bv<i> &t, S s)
{
    t = s;
}

template< typename T1, typename T2 >
template<typename T, typename S>
void HifConcatProxy<T1,T2>::_assign( sc_core::sc_signal<T> &t, S s)
{
    T tmp;
    _assign(tmp, s);
    t = tmp;
}

template< typename T1, typename T2 >
template<typename T, typename S>
void HifConcatProxy<T1,T2>::_assign( sc_core::sc_in<T> &t, S s)
{
    T tmp;
    _assign(tmp, s);
    t = tmp;
}


template< typename T1, typename T2 >
template<typename T, typename S>
void HifConcatProxy<T1,T2>::_assign( sc_core::sc_out<T> &t, S s)
{
    T tmp;
    _assign(tmp, s);
    t = tmp;
}


template< typename T1, typename T2 >
template<typename T, typename S>
void HifConcatProxy<T1,T2>::_assign( sc_core::sc_inout<T> &t, S s)
{
    T tmp;
    _assign(tmp, s);
    t = tmp;
}

template< typename T1, typename T2 >
template< typename X, typename S >
void HifConcatProxy<T1,T2>::_assign( sc_dt::sc_bitref<X> &t, S s)
{
    sc_dt::sc_logic tmp;
    _assign(tmp, s);
    t = tmp;
}

template< typename T1, typename T2 >
template< typename X, typename S >
void HifConcatProxy<T1,T2>::_assign( sc_dt::sc_subref<X> &t, S s)
{
    sc_dt::sc_lv_base tmp;
    tmp = s;
    t = tmp;
}


template< typename T1, typename T2 >
template<typename X, typename Y, typename S>
void HifConcatProxy<T1,T2>::_assign( HifConcatProxy<X,Y> &t, S s)
{
    // recursive case:
    t = s;
}


#ifdef HIF_USE_HDTLIB

template< typename T1, typename T2 >
template<typename S>
void HifConcatProxy<T1,T2>::_assign( hdtlib::hl_logic_t &t, S s)
{
    t = s.to_string()[0];
}

template< typename T1, typename T2 >
template<int i, typename S>
void HifConcatProxy<T1,T2>::_assign( hdtlib::hl_lv_t<i> &t, S s)
{
    t = s;
}

template< typename T1, typename T2 >
template<int i, typename S>
void HifConcatProxy<T1,T2>::_assign( hdtlib::hl_bv_t<i> &t, S s)
{
    t = s;
}

#endif


template< typename T1, typename T2 >
template<typename T3>
int HifConcatProxy<T1,T2>::_getSize(const T3 & )
{
    return 0;
}

template< typename T1, typename T2 >
template<typename T3>
int HifConcatProxy<T1,T2>::_getSize(const sc_core::sc_in<T3> & )
{
    return 0;
}

template< typename T1, typename T2 >
template<typename T3>
int HifConcatProxy<T1,T2>::_getSize(const sc_core::sc_out<T3> & )
{
    return 0;
}

template< typename T1, typename T2 >
template<typename T3>
int HifConcatProxy<T1,T2>::_getSize(const sc_core::sc_inout<T3> & )
{
    return 0;
}

template< typename T1, typename T2 >
template<typename T3>
int HifConcatProxy<T1,T2>::_getSize(const sc_core::sc_signal<T3> & )
{
    return 0;
}

template< typename T1, typename T2 >
template<template<class T> class C, typename A>
int HifConcatProxy<T1,T2>::_getSize(const C<A> & t)
{
    return t.length();
}


template< typename T3, typename T1, typename T2>
HifConcatProxy<T1,T2> hif_concat_target(const T1 & t1, const T2 & t2)
{
    return HifConcatProxy<T1,T2>(t1, t2);
}

} // hif_systemc_extensions

#endif // HIF_SYSTEMC_EXTENSIONS_CONCAT_PROXY__I_HH
