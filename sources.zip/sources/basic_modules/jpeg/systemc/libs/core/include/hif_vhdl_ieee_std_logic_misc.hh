#ifndef HIF_VHDL_IEEE_STD_LOGIC_MISC__HH
#define HIF_VHDL_IEEE_STD_LOGIC_MISC__HH

#include "hif2scSupport/config.hh"

namespace hif_vhdl_ieee_std_logic_misc {


} // hif_vhdl_ieee_std_logic_misc

#endif // HIF_VHDL_IEEE_STD_LOGIC_MISC__HH
