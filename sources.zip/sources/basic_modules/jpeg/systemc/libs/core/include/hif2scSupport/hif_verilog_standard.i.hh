#ifndef HIF_VERILOG_STANDARD_I_HH
#define HIF_VERILOG_STANDARD_I_HH

#include "../hif_verilog_standard.hh"


namespace hif_verilog_standard {


template <int times, int size>
sc_dt::sc_lv<times * size> hif_verilog_iterated_concat (sc_dt::sc_lv<size> expression)
{
    sc_dt::sc_lv<times * size> result;
    unsigned int res_i = 0;
    for (int i = 0; i < times; ++i)
        for (int j = 0; j < size; ++j, ++res_i)
            result [res_i] = expression[j];
    return result;
}

#ifdef HIF_USE_HDTLIB
	template <int times, int size>
    hdtlib::hl_lv_t<times * size> hif_verilog_iterated_concat(hdtlib::hl_lv_t<size> expression)
{
    hdtlib::hl_lv_t<times * size> result;
    unsigned int res_i = 0;
    for (int i = 0; i < times; ++i)
        for (int j = 0; j < size; ++j, ++res_i)
            result.set_bit(res_i, expression[j]);
    return result;
}
#endif


} // hif_verilog_standard

#endif
