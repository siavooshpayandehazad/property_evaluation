#ifndef HIF_SYSTEMC_EXTENSIONS_CONCAT_PROXY__HH
#define HIF_SYSTEMC_EXTENSIONS_CONCAT_PROXY__HH

#include "hif2scSupport/config.hh"

namespace hif_systemc_extensions {

template<class T>
struct TypeSize {};

template<>
struct TypeSize<sc_dt::sc_logic> { enum SizeValue{ SIZE = 1 }; };

template<>
struct TypeSize<sc_dt::sc_bit> { enum SizeValue{ SIZE = 1 }; };

template<>
struct TypeSize<bool> { enum SizeValue{ SIZE = 1 }; };

template<int W>
struct TypeSize<sc_dt::sc_lv<W> > { enum SizeValue{ SIZE = W }; };

template<int W>
struct TypeSize<sc_dt::sc_bv<W> > { enum SizeValue{ SIZE = W }; };

template<>
struct TypeSize<sc_dt::sc_lv_base > { enum SizeValue{ SIZE = -1 }; };

template<>
struct TypeSize<sc_dt::sc_bv_base > { enum SizeValue{ SIZE = -1 }; };

template<class T>
struct TypeSize<sc_core::sc_signal<T> > { enum SizeValue{ SIZE = TypeSize<T>::SIZE }; };

template<class T>
struct TypeSize<sc_core::sc_in<T> > { enum SizeValue{ SIZE = TypeSize<T>::SIZE }; };

template<class T>
struct TypeSize<sc_core::sc_out<T> > { enum SizeValue{ SIZE = TypeSize<T>::SIZE }; };

template<class T>
struct TypeSize<sc_core::sc_inout<T> > { enum SizeValue{ SIZE = TypeSize<T>::SIZE }; };

// For SystemC ref types.
template<template<class T> class C, typename A>
struct TypeSize< C<A> > { enum SizeValue{ SIZE = TypeSize<A>::SIZE }; };


#ifdef HIF_USE_HDTLIB

template<>
struct TypeSize<hdtlib::hl_logic_t> { enum SizeValue{ SIZE = 1 }; };

template<int W>
struct TypeSize<hdtlib::hl_lv_t<W> > { enum SizeValue{ SIZE = W }; };

template<int W>
struct TypeSize<hdtlib::hl_bv_t<W> > { enum SizeValue{ SIZE = W }; };

#endif


template<class T1, class T2>
class HifConcatProxy
{
public:

    enum SizeValue{ SIZE = TypeSize<T2>::SIZE };

    HifConcatProxy(const T1 & t1, const T2 & t2);
    ~HifConcatProxy();
    HifConcatProxy(const HifConcatProxy<T1, T2> & other);

    template<typename T3>
    HifConcatProxy & operator = (T3 t);

#ifdef HIF_USE_HDTLIB
    template<int W>
    HifConcatProxy & operator = (hdtlib::hl_lv_t<W> t);
    template<int W>
    HifConcatProxy & operator = (hdtlib::hl_bv_t<W> t);
#endif

protected:
    const T1 & _t1;
    const T2 & _t2;

    template<typename S>
    void _assign( sc_dt::sc_logic &t, S s);
    template<typename S>
    void _assign( sc_dt::sc_bit &t, S s);
    template<typename S>
    void _assign( bool &t, S s);
    template<int i, typename S>
    void _assign( sc_dt::sc_lv<i> &t, S s);
    template<int i, typename S>
    void _assign( sc_dt::sc_bv<i> &t, S s);
    template<typename T, typename S>
    void _assign( sc_core::sc_signal<T> &t, S s);
    template<typename T, typename S>
    void _assign( sc_core::sc_in<T> &t, S s);
    template<typename T, typename S>
    void _assign( sc_core::sc_out<T> &t, S s);
    template<typename T, typename S>
    void _assign( sc_core::sc_inout<T> &t, S s);
    template<typename X, typename Y, typename S>
    void _assign( HifConcatProxy<X,Y> &t, S s);
    template< typename X, typename S>
    void _assign( sc_dt::sc_bitref<X> &t, S s);
    template< typename X, typename S>
    void _assign( sc_dt::sc_subref<X> &t, S s);

#ifdef HIF_USE_HDTLIB
    template<typename S>
    void _assign( hdtlib::hl_logic_t &t, S s);
    template<int i, typename S>
    void _assign( hdtlib::hl_lv_t<i> &t, S s);
    template<int i, typename S>
    void _assign( hdtlib::hl_bv_t<i> &t, S s);
#endif

    template<typename T3>
    int _getSize(const T3 & t);

    template<typename T3>
    int _getSize(const sc_core::sc_in<T3> & t);
    template<typename T3>
    int _getSize(const sc_core::sc_out<T3> & t);
    template<typename T3>
    int _getSize(const sc_core::sc_inout<T3> & t);
    template<typename T3>
    int _getSize(const sc_core::sc_signal<T3> & t);


    template<template<class T> class C, typename A>
    int _getSize(const C<A> & t);

private:
    HifConcatProxy<T1,T2> operator = (const HifConcatProxy<T1,T2>&);
};



template< typename T1, typename T2, typename T3 >
HifConcatProxy<T1,T2> & hif_concat_target(const T1 & t1, const T2 & t2);

} // hif_systemc_extensions

#include "hif_systemc_extensions_HifConcatProxy.i.hh"

#endif // HIF_SYSTEMC_EXTENSIONS_CONCAT_PROXY__HH
