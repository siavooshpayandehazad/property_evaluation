#ifndef HIF_SYSTEMC_EXTENSIONS_HH
#define HIF_SYSTEMC_EXTENSIONS_HH

#include "hif2scSupport/config.hh"
#include "hif2scSupport/hif_assign.hh"

namespace hif_systemc_extensions {

/// @brief This method is equivalent to mod operator of VHDL.
/// @param a is the numerator.
/// @param n is the divisor.
/// @return The resulting remainder.
HIF2SCSUPPORT_EXPORT
long long int hif_mod( const long long int a, const long long int n );


/// @brief This method is used to avoid SystemC bitref_r types.
/// @tparam T2 The return type.
/// @tparam T1 The argument type.
/// @param param1 The argument.
/// @param param2 The left bound.
/// @param param3 The right bound.
/// @return The resulting slice.
template< typename T2, typename T1 >
T2 hif_range( T1 param1, const long long int param2, const long long int param3 );


/// @brief This method is used to avoid SystemC bitref_r types.
/// @tparam T2 Unused.
/// @tparam T1 The argument type.
/// @param param1 The argument.
/// @param param2 The left bound.
/// @param param3 The right bound.
/// @return The resulting slice.
template< typename T2, typename T1 >
T1 * hif_range( T1 param1[], const long long int param2, const long long int param3 );

/// @brief This method is used to avoid SystemC bitref_r types.
/// @tparam T2 The return type.
/// @tparam T1 The argument type.
/// @param param1 The argument.
/// @param param2 The member index.
/// @return The resulting member.
template< typename T2, typename T1 >
T2 hif_member( T1 param1, const long long int param2);


/// @brief This method is used to avoid SystemC concatref_r types.
/// @tparam T3 The return type.
/// @tparam T1 The first argument type.
/// @tparam T12 The second argument type.
/// @param param1 The first argument.
/// @param param2 The second argument.
/// @return The resulting concat.
template< typename T3, typename T1, typename T2 >
T3 hif_concat( T1 param1, T2 param2 );

template< typename T3, typename T2 >
T3 hif_concat( sc_dt::sc_logic param1, T2 param2 );

template< typename T3, typename T2 >
T3 hif_concat( sc_dt::sc_bit param1, T2 param2 );

template< typename T3, typename T2 >
T3 hif_concat( bool param1, T2 param2 );


/// @brief This method return the last value of given port/signal performing
/// the checking on given last and prev parameters. This function is used
/// to map VHDL attribute last_value.
/// @param s The port or signal.
/// @param last The last value of the port.
/// @param prev The previous value of the port.
/// @return The last value o the port.
template< typename T, typename P >
T hif_lastValue(P & s, T & last, T & prev);


/// @brief This method is used to avoid sc_*_base types, returned by SystemC not operators.
/// @param v The value to be bitwise-negated.
/// @return The negated value.
template< typename T >
T hif_bnot(T v);

/// @name Wrapper functions for sign extensions.
/// @{
template <int size2, int size1>
sc_dt::sc_lv<size2> hif_sxt(sc_dt::sc_lv<size1> arg);

template <int size2, int size1>
sc_dt::sc_bv<size2> hif_sxt(sc_dt::sc_bv<size1> arg);

#ifdef HIF_USE_HDTLIB
template <int size2, int size1>
hdtlib::hl_lv_t<size2> hif_sxt(hdtlib::hl_lv_t<size1> arg);

template <int size2, int size1>
hdtlib::hl_bv_t<size2> hif_sxt(hdtlib::hl_bv_t<size1> arg);
#endif
/// @}


/// @name Relational comparison between arrays.
/// @{
/// @brief This method allow to compare two equal-size arrays element by element
/// to check whether they are equal.
/// @param param1 The inner type of first array.
/// @param param2 The inner type of second array.
/// @return True if they are equal, False otherwise.
template< typename T >
bool hif_arrayEquals(T param1, T param2);

/// @brief This method allow to compare two bi-dimensional equal-size arrays
/// element by element to check whether they are equal.
/// @param param1 The first array.
/// @param param2 The second array.
/// @return True if they are equal, False otherwise.
template< typename T, int size >
bool hif_arrayEquals(T (&param1)[size], T (&param2)[size]);

///@}

/// @name Logic comparisons.
/// @{

/// This method allows to compare two logic types, considering 'X' as false.
/// @param param1 The first logic value.
/// @param param2 The second logic value.
/// @param sign Whether extend with sign.
/// @return The resulting logic value.
template< int W1, int W2 >
sc_dt::sc_logic hif_logicEquals(sc_dt::sc_lv<W1> param1, sc_dt::sc_lv<W2> param2, const bool sign);

/// This method allows to compare two logic types, considering 'X' as false.
/// @param param1 The first logic value.
/// @param param2 The second logic value.
/// @return The resulting logic value.
HIF2SCSUPPORT_EXPORT
sc_dt::sc_logic hif_logicEquals(sc_dt::sc_logic param1, sc_dt::sc_logic param2);

/// This method allows to compare two arrays of logic types, considering 'X' as false.
/// @param param1 The first array.
/// @param param2 The second array.
/// @return The resulting logic value.
template< typename T1, typename T2, int size >
sc_dt::sc_logic hif_logicEquals(T1 (&param1)[size], T2 (&param2)[size], const bool sign);

#ifdef HIF_USE_HDTLIB

/// This method allows to compare two logic types, considering 'X' as false.
/// @param param1 The first logic value.
/// @param param2 The second logic value.
/// @param sign Whether extend with sign.
/// @return The resulting logic value.
template< int W1, int W2 >
hdtlib::hl_logic_t hif_logicEquals_hdtlib(hdtlib::hl_lv_t<W1> param1, hdtlib::hl_lv_t<W2> param2, const bool sign);

/// This method allows to compare two logic types, considering 'X' as false.
/// @param param1 The first logic value.
/// @param param2 The second logic value.
/// @return The resulting logic value.
HIF2SCSUPPORT_EXPORT
hdtlib::hl_logic_t hif_logicEquals_hdtlib(hdtlib::hl_logic_t param1, hdtlib::hl_logic_t param2);

/// This method allows to compare two arrays of logic types, considering 'X' as false.
/// @param param1 The first array.
/// @param param2 The second array.
/// @return The resulting logic value.
template< typename T1, typename T2, int size >
hdtlib::hl_logic_t hif_logicEquals_hdtlib(T1 (&param1)[size], T2 (&param2)[size], const bool sign);

#endif

///@}

/// @name Shift operations
/// @{
/// @brief This method performs the shift between logic vectors

template< int size1, int size2 >
sc_dt::sc_lv<size1> hif_op_shift_left(sc_dt::sc_lv<size1> param1, sc_dt::sc_lv<size2> param2);

template< int size1, int size2 >
sc_dt::sc_lv<size1> hif_op_shift_right_arithmetic(sc_dt::sc_lv<size1> param1, sc_dt::sc_lv<size2> param2);

template< int size1, int size2 >
sc_dt::sc_lv<size1> hif_op_shift_right_logic(sc_dt::sc_lv<size1> param1, sc_dt::sc_lv<size2> param2);

#ifdef HIF_USE_HDTLIB

template< int size1, int size2 >
hdtlib::hl_lv_t<size1> hif_op_shift_left(hdtlib::hl_lv_t<size1> param1, hdtlib::hl_lv_t<size2> param2);

template< int size1, int size2 >
hdtlib::hl_lv_t<size1> hif_op_shift_right_arithmetic(hdtlib::hl_lv_t<size1> param1, hdtlib::hl_lv_t<size2> param2);

template< int size1, int size2 >
hdtlib::hl_lv_t<size1> hif_op_shift_right_logic(hdtlib::hl_lv_t<size1> param1, hdtlib::hl_lv_t<size2> param2);

#endif

/// @}

} // hif_systemc_extensions


#include "hif2scSupport/hif_systemc_extensions_HifAggregate.hh"
#include "hif2scSupport/hif_systemc_extensions_HifConcatProxy.hh"


#include "hif2scSupport/hif_systemc_extensions.i.hh"

#endif // HIF_SYSTEMC_EXTENSIONS_HH
