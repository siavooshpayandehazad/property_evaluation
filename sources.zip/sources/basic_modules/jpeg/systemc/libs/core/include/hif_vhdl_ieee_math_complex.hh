#ifndef HIF_VHDL_IEEE_MATH_COMPLEX__HH
#define HIF_VHDL_IEEE_MATH_COMPLEX__HH

#include "hif2scSupport/config.hh"

namespace hif_vhdl_ieee_math_complex {


} // hif_vhdl_ieee_math_complex

#endif // HIF_VHDL_IEEE_MATH_COMPLEX__HH
