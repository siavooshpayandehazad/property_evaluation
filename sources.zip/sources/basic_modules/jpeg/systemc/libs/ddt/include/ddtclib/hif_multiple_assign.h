#ifndef DDT_C_LIB_MULTIPLE_ASSIGN__H
#define DDT_C_LIB_MULTIPLE_ASSIGN__H

#ifdef __cplusplus
#include <systemc>
#endif

#ifdef __cplusplus
extern "C" {
#endif

    void uintToArrayAssign(bool * target, uint64_t source, uint32_t tleft,
        uint32_t tright, uint32_t sright);
    
    uint64_t arrayToUintAssign(bool * source, uint32_t size);

    void arrayArrayBoolToArrayUintAssign( void * source, uint64_t * target64,
        uint32_t arraySize, uint32_t subArraySize);
    
#ifdef __cplusplus
} // extern C
#endif

#ifdef __cplusplus
    void uintToArrayAssign(sc_core::sc_signal< bool >* sTarget, uint64_t source,
        uint32_t tleft, uint32_t tright, uint32_t sright);
    
    uint64_t arrayToUintAssign(sc_core::sc_signal< bool >* sSource,
        uint32_t size);

     void arrayArrayBoolToArrayUintAssign( void * sSource,
        sc_core::sc_signal< uint64_t > * target64, uint32_t arraySize,
        uint32_t subArraySize);

    void arrayArrayBoolToArrayUintAssign( void * sSource,
        sc_core::sc_signal< uint32_t > * target32, uint32_t arraySize,
        uint32_t subArraySize);

    void arrayArrayBoolToArrayUintAssign( void * sSource,
        sc_core::sc_signal< uint16_t > * target16, uint32_t arraySize,
        uint32_t subArraySize);

    void arrayArrayBoolToArrayUintAssign( void * sSource,
        sc_core::sc_signal< uint8_t > * target8, uint32_t arraySize,
        uint32_t subArraySize);
#endif

#endif
