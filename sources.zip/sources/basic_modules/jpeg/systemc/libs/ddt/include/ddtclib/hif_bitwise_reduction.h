#ifndef DDT_C_LIB_BITWISE_REDUCTION__H
#define DDT_C_LIB_BITWISE_REDUCTION__H

#ifdef __cplusplus
#include <systemc>
#endif

#ifdef __cplusplus
extern "C" {
#endif

    bool andReduce(uint64_t value, uint32_t width);

    bool orReduce(uint64_t value, uint32_t width);

    bool xorReduce(uint64_t value, uint32_t width);

#ifdef __cplusplus
} // extern C
#endif

#endif
