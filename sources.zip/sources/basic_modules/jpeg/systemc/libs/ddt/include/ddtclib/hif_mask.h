#ifndef DDT_C_LIB_MASK__H
#define DDT_C_LIB_MASK__H

#ifdef __cplusplus
extern "C" {
#endif

    uint64_t getMask( uint32_t left, uint32_t right );

    uint64_t getMask0( uint32_t left, uint32_t right );

#ifdef __cplusplus
}
#endif


#endif
