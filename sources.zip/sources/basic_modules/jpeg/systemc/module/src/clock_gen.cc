#include "systemc.h"
#include "../inc/clock_gen.hh"
#include <stdio.h>
#include <ctype.h>


clock_gen::clock_gen(sc_module_name name_)
: sc_module(name_)
{
	SC_THREAD(clk_gen);			// thread per la generazione del clock. posso usare le wait.
}


//generatore del clock
void clock_gen::clk_gen()
{
  while( true )
  {
    clk.write( true );
    wait(CLOCK_PERIOD / 2, sc_core::SC_NS);
    clk.write( false );
    wait(CLOCK_PERIOD / 2, sc_core::SC_NS);
  }
}
