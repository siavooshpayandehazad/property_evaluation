#include "systemc.h"
#define CLOCK_PERIOD 6

class clock_gen : public sc_core::sc_module
{
	
private:

	void clk_gen(void);
 
public:

	sc_core::sc_out< bool > clk;
	
SC_HAS_PROCESS(clock_gen);
clock_gen(sc_module_name name);


};
