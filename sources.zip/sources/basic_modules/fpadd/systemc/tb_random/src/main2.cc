#include "../inc/testbench.hh"
#include "../../module/inc/fpadd.hh"
#include <iostream>

int sc_main(int argc, char **argv)
{
  if (argc == 3)
  {
    // 1. Create testbench
    testbench testbench("testbench");
    testbench.set_length(atoi(argv[1]), atoi(argv[2]));
    
    // 2. Create design under test (dut)
    fpadd design("design_under_test");
    
    // 3. Connect testbench and dut
    sc_core::sc_signal< sc_dt::sc_logic > clk;
    sc_core::sc_signal< sc_dt::sc_logic > add_sub;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_z;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_a;
    sc_core::sc_signal< sc_dt::sc_lv< 32L > > fp_b;
    design.clk(clk);         testbench.clk(clk);
    design.add_sub(add_sub); testbench.add_sub(add_sub);    
    design.fp_a(fp_a);       testbench.fp_a(fp_a);
    design.fp_b(fp_b);       testbench.fp_b(fp_b);
    design.fp_z(fp_z);       testbench.fp_z(fp_z);
    
    // 4. Trace the signals of interest
    sc_core::sc_trace_file * tf_numeric = sc_core::sc_create_vcd_trace_file("fpadd_numeric");
    sc_core::sc_trace_file * tf_boolean = sc_core::sc_create_vcd_trace_file("fpadd_boolean");
    tf_numeric->set_time_unit(PERIOD / 2, sc_core::SC_NS); 
    tf_boolean->set_time_unit(PERIOD / 2, sc_core::SC_NS);
    
    // 4.1. Trace numeric signals
    
    // 4.1.1. Module: fpadd
    // sc_core::sc_trace(tf_numeric, testbench.float_a, "fp_a"); // float
    // sc_core::sc_trace(tf_numeric, testbench.float_b, "fp_b"); // float
    // sc_core::sc_trace(tf_numeric, testbench.float_z, "fp_z"); // float
    sc_core::sc_trace(tf_numeric, design.a_exp, "a_exp");
    sc_core::sc_trace(tf_numeric, design.a_align, "a_align");
    sc_core::sc_trace(tf_numeric, design.a_in, "a_in");
    sc_core::sc_trace(tf_numeric, design.b_exp, "b_exp");
    sc_core::sc_trace(tf_numeric, design.b_align, "b_align");
    sc_core::sc_trace(tf_numeric, design.b_in, "b_in");
    sc_core::sc_trace(tf_numeric, design.exp_base, "exp_base");
    sc_core::sc_trace(tf_numeric, design.exp_base_stage2, "exp_base_stage2");
    sc_core::sc_trace(tf_numeric, design.exp_diff, "exp_diff");
    sc_core::sc_trace(tf_numeric, design.exp_norm, "exp_norm");
    sc_core::sc_trace(tf_numeric, design.sig_norm, "sig_norm");
    sc_core::sc_trace(tf_numeric, design.sig_norm2, "sig_norm2");
    sc_core::sc_trace(tf_numeric, design.z_exp, "z_exp");
    sc_core::sc_trace(tf_numeric, design.add_out, "add_out");
    
    // 4.1.2. Module: unpackfp (i1)
    sc_core::sc_trace(tf_numeric, design.i1.i1.sig, "i1.i1.sig");
    sc_core::sc_trace(tf_numeric, design.i1.i1.exp, "i1.i1.exp");
    sc_core::sc_trace(tf_numeric, design.i1.i1.exp_int, "i1.i1.exp_int");
    sc_core::sc_trace(tf_numeric, design.i1.i1.sig_int, "i1.i1.sig_int");
 
    // 4.1.3. Module: unpackfp (i3)
    sc_core::sc_trace(tf_numeric, design.i1.i3.sig, "i1.i3.sig");
    sc_core::sc_trace(tf_numeric, design.i1.i3.exp, "i1.i3.exp");
    sc_core::sc_trace(tf_numeric, design.i1.i3.exp_int, "i1.i3.exp_int");
    sc_core::sc_trace(tf_numeric, design.i1.i3.sig_int, "i1.i3.sig_int");
  
    // 4.1.4. Module fpalign (i4)
    sc_core::sc_trace(tf_numeric, design.i2.i4.a_in, "i2.i4.a_in");
    sc_core::sc_trace(tf_numeric, design.i2.i4.b_in, "i2.i4.b_in");
    sc_core::sc_trace(tf_numeric, design.i2.i4.diff, "i2.i4.diff");
    sc_core::sc_trace(tf_numeric, design.i2.i4.a_out, "i2.i4.a_out"); 
    sc_core::sc_trace(tf_numeric, design.i2.i4.b_out, "i2.i4.b_out");
    sc_core::sc_trace(tf_numeric, design.i2.i4.b_shift, "i2.i4.b_shift");
    sc_core::sc_trace(tf_numeric, design.i2.i4.diff_int, "i2.i4.diff_int");
    sc_core::sc_trace(tf_numeric, design.i2.i4.shift_b, "i2.i4.shift_b");
    
    // 4.1.5. Module fpswap (i4)
    sc_core::sc_trace(tf_numeric, design.i2.i3.a_in, "i2.i3.a_in");
    sc_core::sc_trace(tf_numeric, design.i2.i3.b_in, "i2.i3.b_in");
    sc_core::sc_trace(tf_numeric, design.i2.i3.a_out, "i2.i3.a_out");
    sc_core::sc_trace(tf_numeric, design.i2.i3.b_out, "i2.i3.b_out");
    
    // 4.1.6. Module fpinvert (i14)
    sc_core::sc_trace(tf_numeric, design.i3.i14.a_in, "i3.i14.a_in");
    sc_core::sc_trace(tf_numeric, design.i3.i14.b_in, "i3.i14.b_in");
    sc_core::sc_trace(tf_numeric, design.i3.i14.a_out, "i3.i14.a_out");
    sc_core::sc_trace(tf_numeric, design.i3.i14.b_out, "i3.i14.b_out");
     
    // 4.1.7. Module fpaddnormalize (i8)
    sc_core::sc_trace(tf_numeric, design.i4.i8.sig_in, "i4.i8.sig_in");
    sc_core::sc_trace(tf_numeric, design.i4.i8.exp_in, "i4.i8.exp_in");
    sc_core::sc_trace(tf_numeric, design.i4.i8.sig_out, "i4.i8.sig_out");
    sc_core::sc_trace(tf_numeric, design.i4.i8.exp_out, "i4.i8.exp_out");
    
    // 4.1.8. Module fpselcomplement (i12)
    sc_core::sc_trace(tf_numeric, design.i4.i12.sig_in, "i4.i12.sig_in");
    sc_core::sc_trace(tf_numeric, design.i4.i12.exp_in, "i4.i12.exp_in");
    sc_core::sc_trace(tf_numeric, design.i4.i12.sig_out, "i4.i12.sig_out");
    sc_core::sc_trace(tf_numeric, design.i4.i12.exp_out, "i4.i12.exp_out");
    
    // 4.1.9. Module fpnormalize (i11)
    sc_core::sc_trace(tf_numeric, design.i5.i11.sig_in, "i5.i11.sig_in");
    sc_core::sc_trace(tf_numeric, design.i5.i11.exp_in, "i5.i11.exp_in");
    sc_core::sc_trace(tf_numeric, design.i5.i11.sig_out, "i5.i11.sig_out");
    sc_core::sc_trace(tf_numeric, design.i5.i11.exp_out, "i5.i11.exp_out");
    
    // 4.1.10. Module fpnormalize (i10)
    sc_core::sc_trace(tf_numeric, design.i5.i10.sig_in, "i5.i10.sig_in");
    sc_core::sc_trace(tf_numeric, design.i5.i10.exp_in, "i5.i10.exp_in");
    sc_core::sc_trace(tf_numeric, design.i5.i10.sig_out, "i5.i10.sig_out");
    sc_core::sc_trace(tf_numeric, design.i5.i10.exp_out, "i5.i10.exp_out");  
    
    // 4.1.11. Module fpack (i2)
    sc_core::sc_trace(tf_numeric, design.i6.i2.exp, "i6.i2.sig_in");
    sc_core::sc_trace(tf_numeric, design.i6.i2.sig, "i6.i2.sig_in");

    // 4.2. Trace boolean signals
    
    // 4.2.1. Module: fpadd
    // sc_core::sc_trace(tf_boolean, design.clk, "clk");
    sc_core::sc_trace(tf_boolean, design.add_sub, "add_sub");
    sc_core::sc_trace(tf_boolean, design.add_sub_out, "add_sub_out");
    sc_core::sc_trace(tf_boolean, design.a_sign, "a_sign");
    sc_core::sc_trace(tf_boolean, design.a_sign_stage2, "a_sign_stage2");
    sc_core::sc_trace(tf_boolean, design.a_sign_stage3, "a_sign_stage3");
    sc_core::sc_trace(tf_boolean, design.a_isinf, "a_isinf");
    sc_core::sc_trace(tf_boolean, design.a_isnan, "a_isnan");
    sc_core::sc_trace(tf_boolean, design.a_isz, "a_isz");
    sc_core::sc_trace(tf_boolean, design.b_xsign, "b_xsign");
    sc_core::sc_trace(tf_boolean, design.b_xsign_stage2, "b_xsign_stage2");
    sc_core::sc_trace(tf_boolean, design.b_xsign_stage3, "b_xsign_stage3");
    sc_core::sc_trace(tf_boolean, design.b_isinf, "b_isinf");
    sc_core::sc_trace(tf_boolean, design.b_isnan, "b_isnan");
    sc_core::sc_trace(tf_boolean, design.b_isz, "b_isz");
    sc_core::sc_trace(tf_boolean, design.ov, "ov");
    sc_core::sc_trace(tf_boolean, design.ov_stage4, "ov_stage4");
    sc_core::sc_trace(tf_boolean, design.z_sign, "z_sign");
    sc_core::sc_trace(tf_boolean, design.z_sign_stage4, "z_sign_stage4");
    sc_core::sc_trace(tf_boolean, design.cin, "cin");
    sc_core::sc_trace(tf_boolean, design.cin_sub, "cin_sub");
    sc_core::sc_trace(tf_boolean, design.invert_a, "invert_a");
    sc_core::sc_trace(tf_boolean, design.invert_b, "invert_b");
    sc_core::sc_trace(tf_boolean, design.isinf_tab, "isinf_tab");
    sc_core::sc_trace(tf_boolean, design.isinf_tab_stage2, "isinf_tab_stage2");
    sc_core::sc_trace(tf_boolean, design.isinf_tab_stage3, "isinf_tab_stage3");
    sc_core::sc_trace(tf_boolean, design.isinf_tab_stage4, "isinf_tab_stage4");
    sc_core::sc_trace(tf_boolean, design.isnan, "isnan");
    sc_core::sc_trace(tf_boolean, design.isnan_stage2, "isnan_stage2");
    sc_core::sc_trace(tf_boolean, design.isnan_stage3, "isnan_stage3");
    sc_core::sc_trace(tf_boolean, design.isnan_stage4, "isnan_stage4");
    sc_core::sc_trace(tf_boolean, design.isz_tab, "isz_tab");
    sc_core::sc_trace(tf_boolean, design.isz_tab_stage2, "isz_tab_stage2");
    sc_core::sc_trace(tf_boolean, design.isz_tab_stage3, "isz_tab_stage3");
    sc_core::sc_trace(tf_boolean, design.isz_tab_stage4, "isz_tab_stage4");
    sc_core::sc_trace(tf_boolean, design.zero, "zero");
    sc_core::sc_trace(tf_boolean, design.zero_stage4, "zero_stage4");
   
    // 4.2.2. Module: unpackfp (i1)  
    sc_core::sc_trace(tf_boolean, design.i1.i1.sign, "i1.i1.sign");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isnan, "i1.i1.isnan");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isinf, "i1.i1.isinf");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isz, "i1.i1.isz");
    sc_core::sc_trace(tf_boolean, design.i1.i1.isdn, "i1.i1.isdn");
    // sc_core::sc_trace(tf_boolean, design.i1.i1.sig_mspw, "i1.i1.sig_mspw");
    sc_core::sc_trace(tf_boolean, design.i1.i1.expz, "i1.i1.expz");
    sc_core::sc_trace(tf_boolean, design.i1.i1.expff, "i1.i1.expff");
    sc_core::sc_trace(tf_boolean, design.i1.i1.sigz, "i1.i1.sigz");
  
    // 4.2.3. Module: unpackfp (i3)  
    sc_core::sc_trace(tf_boolean, design.i1.i3.sign, "i1.i3.sign");
    sc_core::sc_trace(tf_boolean, design.i1.i3.isnan, "i1.i3.isnan");
    sc_core::sc_trace(tf_boolean, design.i1.i3.isinf, "i1.i3.isinf");
    sc_core::sc_trace(tf_boolean, design.i1.i3.isz, "i1.i3.isz");
    sc_core::sc_trace(tf_boolean, design.i1.i3.isdn, "i1.i3.isdn");
    // sc_core::sc_trace(tf_boolean, design.i1.i3.sig_mspw, "i1.i3.sig_mspw");
    sc_core::sc_trace(tf_boolean, design.i1.i3.expz, "i1.i3.expz");
    sc_core::sc_trace(tf_boolean, design.i1.i3.expff, "i1.i3.expff");
    sc_core::sc_trace(tf_boolean, design.i1.i3.sigz, "i1.i3.sigz");
    
    // 4.2.4. Module fpalign (i4)
    sc_core::sc_trace(tf_boolean, design.i2.i4.cin, "i1.i4.sigz");

    // 4.2.5. Module fpswap (i3)
    sc_core::sc_trace(tf_boolean, design.i2.i3.swap_ab, "i2.i3.swap_ab");
    
    // 4.2.6. Module fpinvert (i14))
    sc_core::sc_trace(tf_boolean, design.i3.i14.invert_a, "i3.i14.invert_a");
    sc_core::sc_trace(tf_boolean, design.i3.i14.invert_b, "i3.i14.invert_b");
  
    // 4.2.11. Module fpack (i2) 
    sc_core::sc_trace(tf_boolean, design.i6.i2.sign, "i6.i2.sign");
    sc_core::sc_trace(tf_boolean, design.i6.i2.isnan, "i6.i2.isnan");
    sc_core::sc_trace(tf_boolean, design.i6.i2.isinf, "i6.i2.isinf");
    sc_core::sc_trace(tf_boolean, design.i6.i2.isz, "i6.i2.isz");
   
    sc_core::sc_start(); 
    
    sc_core::sc_close_vcd_trace_file(tf_numeric);
    sc_core::sc_close_vcd_trace_file(tf_boolean);
       
    return 0;
  }
  else
  {
    std::cout << "\nUse in one of the following ways:\n\n"
      << "   ./run.x [seed] [sequence_length]\n\n";
    return 1;
  }
}
