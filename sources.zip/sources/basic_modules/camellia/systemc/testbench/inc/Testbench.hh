#ifndef TESTBENCH__HH
#define TESTBENCH__HH

#include <systemc>

#define PERIOD 500


class Testbench :
    public sc_core::sc_module
{

public:
    SC_HAS_PROCESS(Testbench);

    Testbench(sc_core::sc_module_name name);
    ~Testbench();

    sc_core::sc_out< sc_dt::sc_lv< 128L > > Kin;
    sc_core::sc_out< sc_dt::sc_lv< 128L > > Din;
    sc_core::sc_out< sc_dt::sc_logic > Krdy;
    sc_core::sc_out< sc_dt::sc_logic > Drdy;
    sc_core::sc_out< sc_dt::sc_logic > EncDec;
    sc_core::sc_out< sc_dt::sc_logic > RSTn;
    sc_core::sc_out< sc_dt::sc_logic > EN;
    sc_core::sc_out< sc_dt::sc_logic > CLK;

    sc_core::sc_in< sc_dt::sc_lv< 128L > > Dout;
    sc_core::sc_in< sc_dt::sc_logic > BSY;
    sc_core::sc_in< sc_dt::sc_logic > Kvld;
    sc_core::sc_in< sc_dt::sc_logic > Dvld;

private:
    void _clk_gen();
    void _run();

    const unsigned long long keys[8] = { 0xFEDCBA9876543210ull,
                                       0x0123456789ABCDEFull,
                                       0x0123456789ABCDEFull,
                                       0x8787878787878787ull,
                                       0x133457799BBCDFF1ull,
                                       0x133457799BBCDFF1ull,
                                       0x0E329232EA6D0D73ull,
                                       0x0E329232EA6D0D73ull};

    const unsigned long long secrets[8] = { 0xFEDCBA9876543210ull,
                                          0x0123456789ABCDEFull,
                                          0x596F7572206C6970ull,
                                          0x732061726520736Dull,
                                          0x6F6F746865722074ull,
                                          0x68616E2076617365ull,
                                          0x6C696E650D0A0000ull,
                                          0x133457799BBCDFF1ull };

    const unsigned long long cipher[8] = { 0x0857065648EABE43ull,
                                           0x6767313854966973ull,
                                           0xB9E93E99B3662351ull,
                                           0x562BE542DCFE7038ull,
                                           0xA730F2170E5B533Cull,
                                           0x6D78A247A7E780D4ull,
                                           0xF0CCF80DF8567FFEull,
                                           0x67197BC351AA0B18ull };

};

#endif
