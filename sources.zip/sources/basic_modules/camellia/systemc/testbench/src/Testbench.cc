#include "../inc/Testbench.hh"
#include <iostream>

Testbench::Testbench(sc_core::sc_module_name name)
    : sc_core::sc_module(name),
      Kin("Kin"),
      Din("Din"),
      Krdy("Krdy"),
      Drdy("Drdy"),
      EncDec("EncDec"),
      RSTn("RSTn"),
      EN("EN"),
      CLK("CLK"),
      Dout("Dout"),
      BSY("BSY"),
      Kvld("Kvld"),
      Dvld("Dvld")
{
    SC_THREAD(_clk_gen);

    SC_THREAD(_run);
    sensitive << CLK.pos();
}

Testbench::~Testbench()
{
    // ntd
}

void Testbench::_clk_gen()
{
  while (true)
  {
    CLK.write(sc_dt::sc_logic('1'));
    wait(PERIOD / 2, sc_core::SC_NS);
    CLK.write(sc_dt::sc_logic('0'));
    wait(PERIOD / 2, sc_core::SC_NS);
  }
}

void Testbench::_run()
{
    //reset
    //--------------------------------------------------------------------------
    RSTn.write(sc_dt::sc_logic('0'));
    for (int i = 0; i < 10; ++i) wait();
    //==========================================================================

    //initial setup
    //--------------------------------------------------------------------------
    EN.write(sc_dt::sc_logic('1'));
    RSTn.write(sc_dt::sc_logic('1'));
    Drdy.write(sc_dt::sc_logic('0'));
    Krdy.write(sc_dt::sc_logic('0'));
    EncDec.write(sc_dt::sc_logic('0'));
    Kin.write(sc_dt::sc_lv<128L>(0));
    Din.write(sc_dt::sc_lv<128L>(0));

    for (int i = 0; i < 5; ++i) wait();
    //==========================================================================

    for (int times = 0; times < 10; ++times)
    {
        for (int tests = 0; tests < 8; tests++)
        {
            sc_dt::sc_lv<128L> key = keys[tests];
            sc_dt::sc_lv<128L> secret = secrets[tests];
            sc_dt::sc_lv<128L> result;

            // enc
            EncDec.write(sc_dt::sc_logic('1'));

            // loading a key.
            Kin.write(key);

            Krdy.write(sc_dt::sc_logic('1'));
            while(BSY.read() == sc_dt::sc_logic('0')) wait();
            Krdy.write(sc_dt::sc_logic('0'));
            while(BSY.read() == sc_dt::sc_logic('1')) wait();

            // loading a secret.
            Din.write(secret);

            Drdy.write(sc_dt::sc_logic('1'));
            while(BSY.read() == sc_dt::sc_logic('0')) wait();
            Drdy.write(sc_dt::sc_logic('0'));
            while(BSY.read() == sc_dt::sc_logic('1')) wait();

            result = Dout.read();

            // Check result
            /*
            if (result != cipher[i])
            {
                std::cerr << "Error! We lost a secret!" << std::endl;
                exit(1);
            }*/
            //==========================================================================

            // Coffe Break :)
            for (int i = 0; i < 5; ++i) wait();
            //==========================================================================

            // dec
            EncDec.write(sc_dt::sc_logic('0'));

            // loading a key.
            Kin.write(key);
            Krdy.write(sc_dt::sc_logic('1'));
            while(BSY.read() == sc_dt::sc_logic('0')) wait();
            Krdy.write(sc_dt::sc_logic('0'));
            while(BSY.read() == sc_dt::sc_logic('1')) wait();

            // loading a enc-text.
            Din.write(result);

            Drdy.write(sc_dt::sc_logic('1'));
            while(BSY.read() == sc_dt::sc_logic('0')) wait();
            Drdy.write(sc_dt::sc_logic('0'));
            while(BSY.read() == sc_dt::sc_logic('1')) wait();

            result = Dout.read();
            //==========================================================================

            // Coffe Break :)
            for (int i = 0; i < 5; ++i) wait();
            //==========================================================================

            // Check result
            if (result != secret)
            {
                std::cerr << "Error! We lost a secret!" << std::endl;
                exit(1);
            }
        }
    }
    sc_core::sc_stop();
}
