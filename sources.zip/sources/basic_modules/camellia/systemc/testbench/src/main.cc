#include "../inc/Testbench.hh"
#include "../../module/inc/camellia.hh"
#include <iostream>

int sc_main(int argc, char **argv)
{
    // 1. Create testbench
    Testbench testbench("testbench");

    // 2. Create design under test (dut)
    camellia cam("camellia");

    // 3. Connect testbench and dut
    sc_core::sc_signal< sc_dt::sc_lv< 128L > > Kin;
    sc_core::sc_signal< sc_dt::sc_lv< 128L > > Din;
    sc_core::sc_signal< sc_dt::sc_logic > Krdy;
    sc_core::sc_signal< sc_dt::sc_logic > Drdy;
    sc_core::sc_signal< sc_dt::sc_logic > EncDec;
    sc_core::sc_signal< sc_dt::sc_logic > RSTn;
    sc_core::sc_signal< sc_dt::sc_logic > EN;
    sc_core::sc_signal< sc_dt::sc_logic > CLK;
    sc_core::sc_signal< sc_dt::sc_lv< 128L > > Dout;
    sc_core::sc_signal< sc_dt::sc_logic > BSY;
    sc_core::sc_signal< sc_dt::sc_logic > Kvld;
    sc_core::sc_signal< sc_dt::sc_logic > Dvld;

    testbench.Kin(Kin); cam.Kin(Kin);
    testbench.Din(Din); cam.Din(Din);
    testbench.Krdy(Krdy); cam.Krdy(Krdy);
    testbench.Drdy(Drdy); cam.Drdy(Drdy);
    testbench.EncDec(EncDec); cam.EncDec(EncDec);
    testbench.RSTn(RSTn); cam.RSTn(RSTn);
    testbench.EN(EN); cam.EN(EN);
    testbench.CLK(CLK); cam.CLK(CLK);
    testbench.Dout(Dout); cam.Dout(Dout);
    testbench.BSY(BSY); cam.BSY(BSY);
    testbench.Kvld(Kvld); cam.Kvld(Kvld);
    testbench.Dvld(Dvld); cam.Dvld(Dvld);

    // 4. Trace the signals of interest
    sc_core::sc_trace_file * tf = sc_core::sc_create_vcd_trace_file("camellia_trace");
    tf->set_time_unit(PERIOD / 2, sc_core::SC_NS);
    sc_core::sc_trace(tf, cam.Kin, "Kin");
    sc_core::sc_trace(tf, cam.Din, "Din");
    sc_core::sc_trace(tf, cam.Krdy, "Krdy");
    sc_core::sc_trace(tf, cam.Drdy, "Drdy");
    sc_core::sc_trace(tf, cam.EncDec, "EncDec");
    sc_core::sc_trace(tf, cam.RSTn, "RSTn");
    sc_core::sc_trace(tf, cam.EN, "EN");
    sc_core::sc_trace(tf, cam.CLK, "CLK");
    sc_core::sc_trace(tf, cam.Dout, "Dout");
    sc_core::sc_trace(tf, cam.BSY, "BSY");
    sc_core::sc_trace(tf, cam.Kvld, "Kvld");
    sc_core::sc_trace(tf, cam.Dvld, "Dvld");

    sc_core::sc_start();
    return 0;
}
