#include "hif2scSupport/hif_assign.hh"

namespace hif_systemc_extensions {

sc_dt::sc_logic_value_t to_bit(sc_dt::sc_logic v)
{
    return v.value();
}

sc_dt::sc_logic_value_t to_bit(sc_dt::sc_bit v)
{
    return v.to_bool() ? sc_dt::Log_1 : sc_dt::Log_0;
}

} // hif_systemc_extensions
